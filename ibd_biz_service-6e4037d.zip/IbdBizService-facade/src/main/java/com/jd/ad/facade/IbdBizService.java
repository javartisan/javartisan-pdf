package com.jd.ad.facade;

import com.alibaba.fastjson.JSONObject;

public interface IbdBizService {
    JSONObject fetchJsonData(JSONObject jsonObject);
}
