package com.jd.ad.web.manager.controller;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.facade.IbdBizService;
import com.jd.ad.utils.common.bean.ServiceBean;
import com.jd.ad.web.manager.service.ServiceDataService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * Created by lvmeiyu on 2018/2/23
 */
@Controller
@RequestMapping(value = "/view")
public class ServiceController {

    @Resource
    private ServiceDataService serviceDataService;

    @Resource
    IbdBizService brandService;

    /**
     * 查询服务信息
     *
     * @param request
     * @param model
     * @return
     */
    @RequestMapping(value = "/service/search", method = {RequestMethod.POST, RequestMethod.GET}, produces = {"application/json;charset=UTF-8"})
    public @ResponseBody
    JSONObject query(HttpServletRequest request, Model model) {
        String params = request.getParameter("params");

        JSONObject resultJSON = new JSONObject();
        ServiceBean serviceBean = new ServiceBean();
        serviceBean.setServiceName(params);
        resultJSON = serviceDataService.queryService(serviceBean);

        return resultJSON;

    }

    /**
     * 查询数据
     *
     * @param req
     * @param request
     * @return
     */
    @RequestMapping(value = "/request/queryData", method = {RequestMethod.POST, RequestMethod.GET}, produces = {"application/json;charset=UTF-8"})
    public @ResponseBody
    String queryData(String req, HttpServletRequest request) {

        com.alibaba.fastjson.JSONObject json = com.alibaba.fastjson.JSONObject.parseObject(req);
        return brandService.fetchJsonData(json).toJSONString();
    }

}
