$(document).ready(function() {

});

function createReqData() {
	var reqData = {};
	reqData.header = {};
	reqData.body = {};
    reqData.body.dimensions = {};
    reqData.body.options = {};
    reqData.body.indicators = [];
    reqData.body.attributes = [];

    reqData.header.appkey = document.getElementById("appkey").value;

	var serviceName = document.getElementById("serviceName").value;
	reqData.header.serviceName = serviceName;

    var dimensions = document.getElementById("dimensions").value;
    if (dimensions == null || dimensions.length == 0) {
        reqData.body.dimensions = new Array();
    }else{
		reqData.body.dimensions = JSON.parse(dimensions);
    }

    // options
    var options = document.getElementById("options").value;
    if (options == null || options.length == 0) {
        reqData.body.options = {};
    }else{
        reqData.body.options = JSON.parse(options);
    }

	// indicators
	var indicators = document.getElementById("indicators").value;
	if (indicators == null || indicators.length == 0) {
		reqData.body.indicators = new Array();
	}else{
		var ins = indicators.split("_");
		reqData.body.indicators = ins;
	}

    // indicators
    var attributes = document.getElementById("attributes").value;
    if (attributes == null || attributes.length == 0) {
        reqData.body.attributes = new Array();
    }else{
        var ins = attributes.split("_");
        reqData.body.attributes = ins;
    }
	return reqData;
}

function sendRequest() {
	var reqData = createReqData();
    var reqDataStr = JSON.stringify(reqData);

    $.ajax({
		type : "GET",
		url : "queryData?req=" + reqDataStr,
		success : function(data) {
			setResult(data);
		},
		error : function(xhr, type, exception) {
		}
	});
}

function clearInput() {
	$("#fm").form("clear");
}

function setResult(data) {
	var code = data.header.code;
    var resDataStr = JSON.stringify(data);

	if (code != "200") {
        $("#resultGrid").datagrid({
            loadMsg : '数据加载中....',
            title : '请求结果',
            iconCls : 'icon-edit',
            fit : true,
            url : '',
            nowrap : false,
            striped : true,
            collapsible : true,
            remoteSort : false,
            pagination : false,
            rownumbers : true,
            columns :[[{field:'resData',title:'返回数据：'+resDataStr}]]
        });
        return;
    }
	var size = data.body.size;
	if (size == 0) {
        $("#resultGrid").datagrid({
            loadMsg : '数据加载中....',
            title : '请求结果',
            iconCls : 'icon-edit',
            fit : true,
            url : '',
            nowrap : false,
            striped : true,
            collapsible : true,
            remoteSort : false,
            pagination : false,
            rownumbers : true,
            columns :[[{field:'resData',title:'返回数据：'+resDataStr}]]
        });
		return;
	}

	var meta = data.body.meta.meta;
	var array1 = [];
	var array2 = [];
	$(meta).each(function() {
		array1.push({
			field : '',
			title : '',
			width : ''
		});
	});
	array2.push(array1);
	$(meta).each(function(index, el) {
		array2[0][index]['field'] = el.di;
		array2[0][index]['title'] = el.di;
		array2[0][index]['width'] = "100";
	});
	$("#resultGrid").datagrid({
		loadMsg : '数据加载中....',
		title : '请求结果',
		iconCls : 'icon-edit',
		fit : true,
		url : '',
		nowrap : false,
		striped : true,
		collapsible : true,
		remoteSort : false,
		pagination : false,
		rownumbers : true,
		columns : array2
	});
	var datas = data.body.data;
	var rows = [];
	for (var i = 0; i < size; i++) {
		var row = {};
		$(meta).each(function(index, el) {
			row[el.di] = datas[i][index];
		});
		rows.push(row);
	}
	var list = {
		'total' : size,
		'rows' : rows
	};
	$('#resultGrid').datagrid('loadData', list);
}
