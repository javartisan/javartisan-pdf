$(document).ready(function() {
            $("#serviceGrid").datagrid({
                loadMsg:'数据加载中....',
                title:'服务列表',
                iconCls:'icon-edit',
                fit:true,
                url:'',
                nowrap: false,
                striped: true,
                collapsible:true,
                remoteSort: false,
                pagination:false,
                rownumbers:true,
                fitColumns:true,

                frozenColumns:[[
                    {field:'serviceName',title:'服务名称',width:300}
                ]],
                columns:[[{field:'desc',title:'描述',width:300},
                         {field:'dimensions',title:'维度组',width:200},
                         {field:'indicators',title:'指标组',width:200},
                         {field:'attributes',title:'属性组',width:100},
                         {field:'options',title:'可选入参',width:200},
                ]],
                toolbar:[{
                    id:'btnsearch',
                    text:'查询服务',
                    iconCls:'icon-search',
                    handler:function(){
                        batch('query');
                    }
                },'-', {
                    text: '<input type="text" id="queryContext"/> '
                }]
            });
        });

function batch(param){
		if(param == "query"){
			var queryContext = document.getElementById("queryContext").value;
			var params = {"params":queryContext};
			$.ajax({
				url: 'search',
				method: 'POST',
				data: params,
				dataType: 'json',
				contentType: "application/x-www-form-urlencoded",
				success: function(responseObj){
					var list={'total':responseObj.records,'rows':responseObj.rows};
					$('#serviceGrid').datagrid('loadData', list);
				}
			});
		}
	}

