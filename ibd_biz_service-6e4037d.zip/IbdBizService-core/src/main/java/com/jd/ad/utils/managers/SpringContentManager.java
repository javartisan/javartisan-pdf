package com.jd.ad.utils.managers;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.exception.impl.DispatchException;
import com.jd.ad.exception.impl.ErrorEnum;
import com.jd.ad.log.BrandLog;
import com.jd.ad.service.BrandService;
import com.jd.ad.utils.tools.JudgeBlankValidator;
import com.jd.ad.utils.tools.SpringConfigTool;
import com.jd.bdp.ard.cache.core.CacheConfiguration;
import com.jd.bdp.ard.cache.spring.annotation.CacheEnabled;
import org.springframework.stereotype.Component;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

@Component
public class SpringContentManager {
    //方法容器<methodName, method>
    public static Map<String, Method> methodMap = new HashMap<>();
    //实例容器<methodName, instance>
    public static Map<String, Object> instanceMap = new HashMap<>();

    static {
        BrandLog.logInfo("SpringContentManager init start...");

        for(Map.Entry<String, BrandService> e: SpringConfigTool.getBrandServices().entrySet()) {
            for(Map.Entry<String, Method> entry: e.getValue().getAllMethods().entrySet()) {
                methodMap.put(entry.getKey(), entry.getValue());//方法
                instanceMap.put(entry.getKey(), e.getValue());//实例
            }
        }

        for(Map.Entry<String, Method> entry: methodMap.entrySet()) {
            BrandLog.logInfo("serviceName:" + entry.getKey() + ",methodName:" + entry.getValue().getName() + ",className:" + instanceMap.get(entry.getKey()).getClass().getName());
        }
        BrandLog.logInfo("SpringContentManager init finished...");
    }

    @CacheEnabled(expiredTimeStr = "0 0 8 * * ?" ,validator = JudgeBlankValidator.class)
    public JSONObject invokeMethod(String methodName, JSONObject requestJson) {
        try {
            if(null != methodMap.get(methodName)) {
                return (JSONObject) methodMap.get(methodName).invoke(instanceMap.get(methodName), requestJson);
            } else {
                throw new DispatchException(ErrorEnum.SERVICE_NOT_EXIST.code, "No Such Service!");
            }
        } catch (IllegalAccessException e) {
            BrandLog.logError("Invoke error", e);
            throw new DispatchException(ErrorEnum.EXCP_OCCURRED.code, "Invoke error");
        } catch (InvocationTargetException e) {
            BrandLog.logError("Invoke error", e);
            throw new DispatchException(ErrorEnum.EXCP_OCCURRED.code, "Invoke error");
        }
    }
}
