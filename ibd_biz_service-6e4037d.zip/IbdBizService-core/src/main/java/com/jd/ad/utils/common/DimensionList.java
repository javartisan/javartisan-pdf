package com.jd.ad.utils.common;

/**
 * Created by lvmeiyu on 2018/1/4
 */

public class DimensionList {

    // 开始时间
    public static final String STIME = "StartTime";
    // 结束时间
    public static final String ETIME = "EndTime";
    // 开始时间
    public static final String LOGICAL_START_TIME = "LogicalStartTime";
    // 结束时间
    public static final String LOGICAL_END_TIME = "LogicalEndTime";
    // 开始时间
    public static final String PROCESS_START_TIME = "ProcessStartTime";
    // 结束时间
    public static final String PROCESS_END_TIME = "ProcessEndTime";

    // 品牌
    public static final String BRAND_ID = "BrandId";
    // 品牌
    public static final String MAIN_BRANDID = "MainBrandId";
    // 三级类目
    public static final String THIRDIND_ID = "ThirdIndId";
    // 店铺
    public static final String SHOP_ID = "ShopId";
    // 终端
    public static final String TERMINAL_ID = "TerminalId";
    // 店铺类型
    public static final String SHOP_TYPE = "ShopType";
    // 日期
    public static final String DATE_TIME = "DateTime";
    // 一级流量来源
    public static final String First_Source_Id = "FirstSourceId";
    // 二级流量来源
    public static final String Second_Source_Id = "SecondSourceId";
}
