package com.jd.ad.dao.bean.ibd;

import com.alibaba.fastjson.annotation.JSONField;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by dongzhe6 on 2018/3/29.
 * Copyright @ 2004-2018 JD
 */
public abstract class AbstractParam {
    // 开始时间
    @JSONField(name = "LogicalStartTime")
    private String logicalStartTime;
    // 结束时间
    @JSONField(name = "LogicalEndTime")
    private String logicalEndTime;
    // processDate
    @JSONField(name = "ProcessTime")
    private String processTime;
    // 店铺Id
    @JSONField(name = "ShopId")
    private Set<String> shopId;
    // 主品牌
    @JSONField(name = "BrandId")
    private String brandId;
    // 渠道
    @JSONField(name = "ChannelId")
    private String channelId;
    // limit
    @JSONField(name = "Limit")
    private Integer limit = 2000;
    // 排序字段
    @JSONField(name = "OrderBy")
    private List<String> orderBy;
    // 升降序
    @JSONField(name = "Order")
    private String order;

    private List<String> columns;

    public void setLogicalStartTime(String logicalStartTime){
        this.logicalStartTime = logicalStartTime;
    }

    public String getLogicalStartTime() {
        return logicalStartTime;
    }

    public void setLogicalEndTime(String logicalEndTime){
        this.logicalEndTime = logicalEndTime;
    }

    public String getLogicalEndTime() {
        return logicalEndTime;
    }

    public String getProcessTime() {
        return processTime;
    }

    public void setProcessTime(String processTime) {
        this.processTime = processTime;
    }

    public Set<String> getShopId() {
        if (shopId == null || shopId.isEmpty()) {
            Set<String> set = new HashSet<>();
            // 设置一个搜索不到的shopId，避免返回所有的店铺数据，当店铺id是空的时候
            set.add("-1");
            return set;
        }
        return shopId;
    }

    public void setShopId(Set<String> shopId) {
        this.shopId = shopId;
    }

    public String getBrandId() {
        return brandId;
    }

    public void setBrandId(String brandId) {
        this.brandId = brandId;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public List<String> getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(List<String> orderBy) {
        this.orderBy = orderBy;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public List<String> getColumns() {
        return columns;
    }

    public void setColumns(List<String> columns) {
        this.columns = columns;
    }

}
