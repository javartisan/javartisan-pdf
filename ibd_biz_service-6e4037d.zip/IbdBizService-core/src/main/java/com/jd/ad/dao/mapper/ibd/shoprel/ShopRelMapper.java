package com.jd.ad.dao.mapper.ibd.shoprel;

import com.jd.ad.dao.bean.ibd.shoprel.ShopRelParam;
import org.springframework.stereotype.Repository;

import java.util.LinkedHashMap;
import java.util.List;


@Repository
public interface ShopRelMapper {

    List<LinkedHashMap<String, Object>> getBrandList(ShopRelParam param);

    List<LinkedHashMap<String, Object>> getSectionList(ShopRelParam param);
}
