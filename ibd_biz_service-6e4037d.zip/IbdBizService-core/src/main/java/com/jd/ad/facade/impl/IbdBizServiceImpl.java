package com.jd.ad.facade.impl;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.facade.IbdBizService;
import com.jd.ad.procedure.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class IbdBizServiceImpl implements IbdBizService {

    @Autowired
    Processor processor;

    public JSONObject fetchJsonData(JSONObject jsonObject) {
        return  processor.process(jsonObject);
    }
}
