package com.jd.ad.service.impl.ibd;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.dao.bean.ibd.flow.FlowParam;
import com.jd.ad.dao.mapper.ibd.flow.FlowGeneralMapper;
import com.jd.ad.service.BrandService;
import com.jd.ad.utils.common.transform.impl.TransformForClickHouse;
import com.jd.ad.utils.tools.MultiQueryTool;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/**
 * Created by dongzhe6 on 2018/3/28.
 * Copyright @ 2004-2018 JD
 */
//流量概况 提供 "数据概览" "流量趋势" "店铺流量" 三个子功能.
@Service
public class FlowGeneralService extends BrandService {

    @Resource
    FlowGeneralMapper flowGeneralMapper;

    //数据概览
    public JSONObject getIbdFlowGeneralOverview(JSONObject jsonObject) {
        FlowParam parameter = generateFullParam(jsonObject,FlowParam.class);
        List<LinkedHashMap<String, Object>> result = flowGeneralMapper.getIbdFlowGeneralOverview(parameter);
        return new TransformForClickHouse().transform(result);
    }

    //流量趋势
    public JSONObject getIbdFlowTrend(JSONObject jsonObject) {
        FlowParam parameter = generateFullParam(jsonObject,FlowParam.class);
        List<LinkedHashMap<String, Object>> result = flowGeneralMapper.getIbdFlowTrend(parameter);
        return new TransformForClickHouse().transform(result);
    }

    //店铺流量
    public JSONObject getIbdShopFlowGeneral(JSONObject jsonObject) {
        FlowParam param = generateFullParam(jsonObject,FlowParam.class);

        List<List<LinkedHashMap<String, Object>>> results = new ArrayList<>();
        List<Set<String>> shopSpilts = MultiQueryTool.split(param.getShopId(), MultiQueryTool.SHOP_ID_SIZE);
        List<Future> futures = new ArrayList<>();
        for (int i = 0; i < shopSpilts.size(); i++) {
            final FlowParam pieceParam = (FlowParam) param.clone();
            pieceParam.setShopId(shopSpilts.get(i));
            Future f = MultiQueryTool.CACHE_THREAD_POOL.submit(new Callable<Object>() {
                public List<LinkedHashMap<String, Object>> call() {
                    return flowGeneralMapper.getIbdShopFlowGeneral(pieceParam);
                }
            });
            futures.add(f);
        }
        for(Future f: futures){
            try{
                results.add((List<LinkedHashMap<String, Object>>)f.get());
            }catch (InterruptedException | ExecutionException e){
                e.printStackTrace();
            }
        }
        // merge, order and cut
        List<LinkedHashMap<String, Object>> result = MultiQueryTool.merge(results, param.getOrderBy(), param.getOrder(), param.getLimit());
        return new TransformForClickHouse().transform(result);
    }

}
