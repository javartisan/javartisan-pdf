package com.jd.ad.utils.common.transform.impl;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.exception.impl.ErrorEnum;
import com.jd.ad.exception.impl.ValidateException;
import com.jd.ad.log.BrandLog;
import com.jd.ad.utils.common.transform.TransformResult;
import org.apache.commons.lang.StringUtils;

import java.math.BigInteger;
import java.util.*;

import static com.jd.ad.utils.common.Protocol.*;

/**
 * Created by lvmeiyu on 2018/1/10
 */

public class TransformForClickHouse implements TransformResult<List<LinkedHashMap<String, Object>>, JSONObject> {

    private static LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();

    static {
        map.put("Double", "double");
        map.put("BigInteger", "long");
        map.put("String", "String");
        map.put("Long", "long");
        map.put("Integer", "int");
    }

    public JSONObject transform(List<LinkedHashMap<String, Object>> sourceResult) {

        JSONObject body = new JSONObject();
        int size = sourceResult.size();

        try {
            // di以及type
            List<JSONObject> diTypeList = new ArrayList<JSONObject>();
            JSONObject indexJson = new JSONObject();

            // 返回data数据
            List<List<Object>> data = new ArrayList<List<Object>>();
            // 获取返回值的名称
            List<String> allFields = new ArrayList<String>();

            for (int i = 0; i < size; i++) {

                LinkedHashMap map = sourceResult.get(i);
                List<Object> lineData = new ArrayList<Object>();

                if (i == 0) {
                    int index = 0;
                    Set<String> keys = map.keySet();
                    for (String key : keys) {
                        allFields.add(key);
                        Object value = map.get(key);
                        if(value instanceof BigInteger){
                            value = ((BigInteger)value).longValue();
                        }
                        String type = value.getClass().getName();
                        if (type.split("\\.").length > 1) {
                            type = type.substring(type.lastIndexOf(".") + 1, type.length());
                        }
                        JSONObject diJson = new JSONObject();
                        diJson.put(P_DI, key);
                        diJson.put(P_TYPE, typeTransform(type));
                        diTypeList.add(diJson);
                        indexJson.put(key, index++);

                        lineData.add(value);
                    }
                } else {
                    for (String str : allFields) {
                        Object value = map.get(str);
                        if(value instanceof BigInteger){
                            value = ((BigInteger)value).longValue();
                        }
                        lineData.add(value);
                    }
                }
                data.add(lineData);
            }

            JSONObject meta = new JSONObject();
            meta.put(P_META_INDEX, indexJson);
            meta.put(P_META, diTypeList);

            body.put(P_DATA, data);
            body.put(P_META, meta);
        } catch (Exception e) {
            BrandLog.logError(e.getMessage(), e);
            throw new ValidateException(ErrorEnum.DATA_TRANSFORM_ERROR.code, e.getMessage());
        }

        body.put(P_SIZE, size);
        return body;
    }

    public static String typeTransform(String typeName) {
        String returnType = map.get(typeName.trim());
        if (StringUtils.isEmpty(returnType)) {
            return typeName;
        }
        return returnType;
    }

    public static void main(String args[]){
        List<LinkedHashMap<String, Object>> result = new ArrayList<>();
        LinkedHashMap<String, Object> map = new LinkedHashMap();
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        result.add(map);
        System.out.println(new TransformForClickHouse().transform(result));
    }

}
