package com.jd.ad.service.impl.ibd;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.dao.bean.ibd.shoprel.ShopRelParam;
import com.jd.ad.dao.mapper.ibd.shoprel.ShopRelMapper;
import com.jd.ad.service.BrandService;
import com.jd.ad.utils.common.transform.impl.TransformForClickHouse;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.LinkedHashMap;
import java.util.List;

@Service
public class ShopRelService extends BrandService {

    @Resource
    ShopRelMapper shopRelMapper;

    public JSONObject getBrandList(JSONObject jsonObject) {
        ShopRelParam parameter = generateParam(jsonObject,ShopRelParam.class);
        List<LinkedHashMap<String, Object>> result = shopRelMapper.getBrandList(parameter);
        return new TransformForClickHouse().transform(result);
    }

    public JSONObject getSectionList(JSONObject jsonObject) {
        ShopRelParam parameter = generateParam(jsonObject,ShopRelParam.class);
        List<LinkedHashMap<String, Object>> result = shopRelMapper.getSectionList(parameter);
        return new TransformForClickHouse().transform(result);
    }



}
