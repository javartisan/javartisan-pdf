package com.jd.ad.procedure;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jd.ad.exception.BrandException;
import com.jd.ad.log.BrandLog;
import com.jd.ad.procedure.validator.SValidatorProxy;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import static com.jd.ad.utils.common.Protocol.*;

@Component
public class Processor {

    @Autowired
    private SValidatorProxy proxy;

    //分发类
    @Autowired
    Dispatcher dispatcher;

    public JSONObject process(JSONObject requestJson) {

        BrandLog.logInfo(requestJson.toJSONString());
        // 响应消息
        final JSONObject resp = new JSONObject();
        // 响应消息头
        final JSONObject header = new JSONObject();
        // 响应消息体
        JSONObject body ;

        try {
            proxy.validate(requestJson);
            body = dispatcher.dispatch(requestJson);

            header.put(P_CODE, "200");
            header.put(P_DESC, "successful");
            if(body == null){
                body = emptyResult();
            }
            if ( body.getJSONArray(P_DATA) != null ){
                body.put(P_SIZE, body.getJSONArray(P_DATA).size());
            } else {
                body.put(P_SIZE,0);
            }
            resp.put(P_HEADER, header);
            resp.put(P_BODY, body);

            return resp;
        } catch (Throwable e) {
            if (e instanceof BrandException)
                return ((BrandException) e).returnJson();
            else {
                BrandLog.logError("uncatched error", e);
                return new JSONObject();
            }
        }
    }

    private JSONObject emptyResult(){
        JSONObject jsonResult = new JSONObject();
        JSONArray data = new JSONArray();
        jsonResult.put(P_DATA,data);
        return jsonResult;
    }

}
