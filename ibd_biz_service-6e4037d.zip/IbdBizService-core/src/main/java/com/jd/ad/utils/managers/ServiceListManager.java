package com.jd.ad.utils.managers;

import com.jd.ad.utils.common.Protocol;
import com.jd.ad.utils.common.bean.ServiceBean;
import com.jd.ad.utils.tools.IniReader;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.*;

/**
 * Created by lvmeiyu on 2018/2/24
 */

@Component
public class ServiceListManager {

    public static Map<String, ServiceBean> serviceMap = new HashMap<String, ServiceBean>();

    static {
        loadService();
    }

    public static void loadService() {

        HashMap<String, Properties> sections = IniReader.getSections();

        for (String key : sections.keySet()) {
            Properties properties = sections.get(key);
            ServiceBean serviceBean = new ServiceBean();
            serviceBean.setServiceName(key);
            serviceBean.setDimensions(properties.getProperty(Protocol.P_DIMENSIONS));
            serviceBean.setIndicators(properties.getProperty(Protocol.P_INDICATORS));
            serviceBean.setDesc(properties.getProperty(Protocol.P_DESC));
            serviceBean.setOptions(properties.getProperty(Protocol.P_OPTIONS));
            serviceBean.setAttributes(properties.getProperty(Protocol.P_ATTRIBUTES));
            serviceMap.put(key, serviceBean);
        }
    }

    public static List<ServiceBean> getServiceMap(String serviceName) {
        List<ServiceBean> serviceBeanList = new ArrayList<ServiceBean>();
        if (StringUtils.isEmpty(serviceName)) {
            serviceBeanList.addAll(serviceMap.values());
        } else {
            serviceBeanList.add(serviceMap.get(serviceName));
        }
        return serviceBeanList;
    }

    public static ServiceBean getServiceBean(String serviceName) {
        if (!StringUtils.isEmpty(serviceName)) {
            return serviceMap.get(serviceName);
        }
        return null;
    }

}
