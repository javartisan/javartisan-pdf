package com.jd.ad.service.impl.ibd;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.dao.bean.ibd.commodity.CommodityDetailParam;
import com.jd.ad.dao.mapper.ibd.commodity.CommodityGeneralMapper;
import com.jd.ad.service.BrandService;
import com.jd.ad.utils.common.transform.impl.TransformForClickHouse;
import com.jd.ad.utils.tools.MultiQueryTool;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/**
 * Created by dongzhe6 on 2018/4/2.
 * Copyright @ 2004-2018 JD
 */
//商品概况 提供 "数据概览" "数据趋势" "店铺商品" 三个个子功能.
@Service
public class CommodityGeneralService extends BrandService {

    @Resource
    CommodityGeneralMapper commodityGeneralMapper;

    //SKU 数据概览
    public JSONObject getIbdSkuCommodityGeneralOverview(JSONObject jsonObject) {
        CommodityDetailParam parameter = generateFullParam(jsonObject, CommodityDetailParam.class);
        List<LinkedHashMap<String, Object>> result = commodityGeneralMapper.getIbdSkuCommodityGeneralOverview(parameter);
        return new TransformForClickHouse().transform(result);
    }

    //SPU 数据概览
    public JSONObject getIbdSpuCommodityGeneralOverview(JSONObject jsonObject) {
        CommodityDetailParam parameter = generateFullParam(jsonObject, CommodityDetailParam.class);
        List<LinkedHashMap<String, Object>> result = commodityGeneralMapper.getIbdSpuCommodityGeneralOverview(parameter);
        return new TransformForClickHouse().transform(result);
    }

    //SKU 店铺流量
    public JSONObject getIbdSkuShopCommodityGeneral(JSONObject jsonObject) {
        CommodityDetailParam param = generateFullParam(jsonObject, CommodityDetailParam.class);

        List<List<LinkedHashMap<String, Object>>> results = new ArrayList<>();
        List<Set<String>> shopSpilts = MultiQueryTool.split(param.getShopId(), MultiQueryTool.SHOP_ID_SIZE);
        List<Future> futures = new ArrayList<>();
        for (int i = 0; i < shopSpilts.size(); i++) {
            final CommodityDetailParam pieceParam = (CommodityDetailParam) param.clone();
            pieceParam.setShopId(shopSpilts.get(i));
            Future f = MultiQueryTool.CACHE_THREAD_POOL.submit(new Callable<Object>() {
                public List<LinkedHashMap<String, Object>> call() {
                    return commodityGeneralMapper.getIbdSkuShopCommodityGeneral(pieceParam);
                }
            });
            futures.add(f);
        }
        for(Future f: futures){
            try{
                results.add((List<LinkedHashMap<String, Object>>)f.get());
            }catch (InterruptedException | ExecutionException e){
                e.printStackTrace();
            }
        }
        // merge, order and cut
        List<LinkedHashMap<String, Object>> result = MultiQueryTool.merge(results, param.getOrderBy(), param.getOrder(), param.getLimit());
        return new TransformForClickHouse().transform(result);
    }

    //SPU 店铺流量
    public JSONObject getIbdSpuShopCommodityGeneral(JSONObject jsonObject) {
        CommodityDetailParam param = generateFullParam(jsonObject, CommodityDetailParam.class);

        List<List<LinkedHashMap<String, Object>>> results = new ArrayList<>();
        List<Set<String>> shopSpilts = MultiQueryTool.split(param.getShopId(), MultiQueryTool.SHOP_ID_SIZE);
        List<Future> futures = new ArrayList<>();
        for (int i = 0; i < shopSpilts.size(); i++) {
            final CommodityDetailParam pieceParam = (CommodityDetailParam) param.clone();
            pieceParam.setShopId(shopSpilts.get(i));
            Future f = MultiQueryTool.CACHE_THREAD_POOL.submit(new Callable<Object>() {
                public List<LinkedHashMap<String, Object>> call() {
                    return commodityGeneralMapper.getIbdSpuShopCommodityGeneral(pieceParam);
                }
            });
            futures.add(f);
        }
        for(Future f: futures){
            try{
                results.add((List<LinkedHashMap<String, Object>>)f.get());
            }catch (InterruptedException | ExecutionException e){
                e.printStackTrace();
            }
        }
        // merge, order and cut
        List<LinkedHashMap<String, Object>> result = MultiQueryTool.merge(results, param.getOrderBy(), param.getOrder(), param.getLimit());
        return new TransformForClickHouse().transform(result);
    }

    //SKU 数据趋势
    public JSONObject getIbdSkuCommodityTrend(JSONObject jsonObject) {
        CommodityDetailParam parameter = generateFullParam(jsonObject, CommodityDetailParam.class);
        List<LinkedHashMap<String, Object>> result = commodityGeneralMapper.getIbdSkuCommodityTrend(parameter);
        return new TransformForClickHouse().transform(result);
    }

    //SPU 数据趋势
    public JSONObject getIbdSpuCommodityTrend(JSONObject jsonObject) {
        CommodityDetailParam parameter = generateFullParam(jsonObject, CommodityDetailParam.class);
        List<LinkedHashMap<String, Object>> result = commodityGeneralMapper.getIbdSpuCommodityTrend(parameter);
        return new TransformForClickHouse().transform(result);
    }
}
