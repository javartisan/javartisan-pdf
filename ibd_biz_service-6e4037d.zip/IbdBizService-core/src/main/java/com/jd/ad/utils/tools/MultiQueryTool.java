package com.jd.ad.utils.tools;

import com.jd.ad.log.BrandLog;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MultiQueryTool {

    public static String ORDER_DESC = "desc";
    public static String ORDER_ASC = "asc";
    public static int SHOP_ID_SIZE = 5000;
    public static int NO_LIMIT = 0;
    public static ExecutorService CACHE_THREAD_POOL = Executors.newCachedThreadPool();

    // spilt shopIds
    public static <T> List<Set<T>> split(Set<T> resSet, int count){
        List<T> resList = new ArrayList<>(resSet);
        List<Set<T>> ret = new ArrayList<>();
        if(resList == null || count < 1)
            return ret ;
        int size = resList.size();
        if(size <= count){
            ret.add(resSet);
        }else{
            int pre = size/count;
            int last = size%count;
            for(int i = 0; i < pre; i++){
                Set<T> itemList = new HashSet<>();
                for(int j = 0; j < count; j++){
                    itemList.add(resList.get(i*count+j));
                }
                ret.add(itemList);
            }
            if(last > 0){
                Set<T> itemList = new HashSet<>();
                for(int i = 0; i < last; i++){
                    itemList.add(resList.get(pre*count + i));
                }
                ret.add(itemList);
            }
        }
        return ret;
    }

    // merge order and cut, only for numeric
    public static List<LinkedHashMap<String, Object>> merge(
            List<List<LinkedHashMap<String, Object>>> results, List<String> orderBy, String order, Integer limit){
        BrandLog.logInfo("merge data.orderBy=" + orderBy + ";order=" + order + ";limit=" + limit);
        if (results == null || results.size() == 0){
            return new ArrayList<>();
        }
        if (results.size() == 1){
            return results.get(0);
        }
        List<LinkedHashMap<String, Object>> result = new ArrayList<>();
        final List<String>  compareBy= orderBy;
        final String compareOrder = order;
        for (List<LinkedHashMap<String, Object>> ele: results){
            if (ele == null || ele.size() < 1){
                continue;
            }
            result.addAll(ele);
            if (orderBy != null && orderBy.size() != 0 && ! StringUtils.isEmpty(order)){
                Collections.sort(result, new Comparator<LinkedHashMap<String, Object>>(){
                    public int compare(LinkedHashMap<String, Object> arg0, LinkedHashMap<String, Object> arg1) {
                        if (compareOrder.toLowerCase().equals(ORDER_DESC)){
                            return compareArg(compareBy, arg0, arg1);
                        }else{
                            return compareArg(compareBy, arg1, arg0);
                        }
                    }
                });
            }
            // limit
            if (limit != null && limit != NO_LIMIT && result.size() > limit){
                result = result.subList(0, limit);
            }
        }
        return result;
    }


    public static int compareArg(List<String> compareBy, LinkedHashMap<String, Object> arg0, LinkedHashMap<String, Object> arg1){
        int comRes = 0;
        for (String compareKey: compareBy){
            if (arg0.get(compareKey) instanceof Number && arg1.get(compareKey) instanceof Number){
                comRes = new BigDecimal(arg1.get(compareKey).toString()).compareTo(new BigDecimal(arg0.get(compareKey).toString()));
            }else{
                int stringComRes = arg1.get(compareKey).toString().compareTo(arg0.get(compareKey).toString());
                if (stringComRes > 0){
                    comRes = 1;
                }else if(stringComRes < 0){
                    comRes = -1;
                }
            }
            if (comRes != 0){
                return comRes;
            }
        }
        return comRes;
    }

}
