package com.jd.ad.service.impl.ibd;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.dao.bean.ibd.trade.TradeParam;
import com.jd.ad.service.BrandService;
import com.jd.ad.utils.common.transform.impl.TransformForClickHouse;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import com.jd.ad.dao.mapper.ibd.trade.TradeGeneralMapper;

import java.util.*;


@Service
public class TradeGeneralService extends BrandService {

    @Resource
    TradeGeneralMapper tradeGeneralMapper;

    public JSONObject getIbdTradeGeneralOverview(JSONObject jsonObject) {
        TradeParam param = generateFullParam(jsonObject,TradeParam.class);
        List<LinkedHashMap<String, Object>> result = tradeGeneralMapper.getIbdTradeGeneralOverview(param);
        return new TransformForClickHouse().transform(result);
    }

    public JSONObject getBndTradeGeneralTrend(JSONObject jsonObject) {
        TradeParam param = generateFullParam(jsonObject,TradeParam.class);
        List<LinkedHashMap<String, Object>> result = tradeGeneralMapper.getBndTradeGeneralTrend(param);
        return new TransformForClickHouse().transform(result);
    }


    public JSONObject getIbdTradeShopDetail(JSONObject jsonObject) {
        TradeParam param = generateFullParam(jsonObject,TradeParam.class);
        List<LinkedHashMap<String, Object>> result = tradeGeneralMapper.getIbdTradeShopDetail(param);
        return new TransformForClickHouse().transform(result);
    }


    public JSONObject getIbdTradeBrandDetail(JSONObject jsonObject) {
        TradeParam param = generateFullParam(jsonObject,TradeParam.class);
        List<LinkedHashMap<String, Object>> result = tradeGeneralMapper.getIbdTradeBrandDetail(param);
        return new TransformForClickHouse().transform(result);
    }


    public JSONObject getIbdTradeSecondItemDetail(JSONObject jsonObject) {
        TradeParam param = generateFullParam(jsonObject,TradeParam.class);
        List<LinkedHashMap<String, Object>> result = tradeGeneralMapper.getIbdTradeSecondItemDetail(param);
        return new TransformForClickHouse().transform(result);
    }


    public JSONObject getIbdTradeThirdItemDetail(JSONObject jsonObject) {
        TradeParam param = generateFullParam(jsonObject,TradeParam.class);
        List<LinkedHashMap<String, Object>> result = tradeGeneralMapper.getIbdTradeThirdItemDetail(param);
        return new TransformForClickHouse().transform(result);
    }

}
