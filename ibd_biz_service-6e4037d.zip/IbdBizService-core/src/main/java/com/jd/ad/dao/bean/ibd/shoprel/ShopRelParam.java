package com.jd.ad.dao.bean.ibd.shoprel;

import com.jd.ad.dao.bean.ibd.AbstractParam;

public class ShopRelParam extends AbstractParam implements Cloneable{

    @Override
    public Object clone() {
        ShopRelParam param = null;
        try{
            param = (ShopRelParam)super.clone();
        }catch(CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return param;
    }

}
