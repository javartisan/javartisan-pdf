package com.jd.ad.procedure.validator;

import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Component;

@Component
public interface Validator {
     void validate(final JSONObject req) throws Exception;

}
