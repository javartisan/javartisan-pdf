package com.jd.ad.procedure.validator.impl;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.exception.impl.ErrorEnum;
import com.jd.ad.exception.impl.ValidateException;
import com.jd.ad.procedure.validator.Validator;
import org.springframework.stereotype.Component;

import static com.jd.ad.utils.common.Protocol.*;


/**
 * 对接口请求的请求参数是否按标准输入进行校验
 */
@Component
public class SStrictValidator implements Validator {

    private static final String[] REQUIREDPARAMNAMES = new String[]{P_SERVICENAME, P_APPKEY};

    @Override
    public void validate(JSONObject req) throws Exception {
        JSONObject header = req.getJSONObject(P_HEADER);
        if (header == null) {
            throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, String.format("request params is invalid,no [%s]，request params is [%s]", P_HEADER, req));
        }
        JSONObject body = req.getJSONObject(P_BODY);
        if (body == null) {
            throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, String.format("request params is invalid,no [%s]，request params is [%s]", P_BODY, req));
        }
        for (String paramName : REQUIREDPARAMNAMES) {
            if (!header.containsKey(paramName)) {
                throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, String.format("request params must have [%s]", paramName));
            }
        }
    }
}
