package com.jd.ad.utils.common;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.jd.ad.dao.bean.brand.flow.FlowParam;
import com.jd.ad.dao.bean.brand.oldtrade.TradeParamVo;
import com.jd.ad.dao.bean.brand.oldtrade.TradePageParamVo;
import com.jd.ad.exception.impl.ErrorEnum;
import com.jd.ad.exception.impl.ValidateException;
import com.jd.ad.log.BrandLog;
import com.jd.bdp.ard.cache.core.CacheConfiguration;
import com.jd.bdp.ard.cache.jimdb.JimClientFactory;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.concurrent.TimeUnit;

import static com.jd.ad.utils.common.Protocol.*;

/**
 * Created by lvmeiyu on 2018/1/13
 */

public class ReqUtils {

    private static LoadingCache<String, String> brandMapper = CacheBuilder.newBuilder()
            .maximumSize(50000)
            .refreshAfterWrite(1, TimeUnit.HOURS)
            .build(new CacheLoader<String, String>() {
                @Override
                public String load(String key) throws Exception {
                    return JimClientFactory.getJimClient(CacheConfiguration.DEFAULT_GROUP).get(key);
                }
            });

    public static TradeParamVo generateTradeParams(JSONObject jsonObject) {
        JSONObject bodyMsg = jsonObject.getJSONObject(P_BODY).getJSONObject(P_DIMENSIONS);

        TradeParamVo params =
                JSONObject.toJavaObject(bodyMsg, TradeParamVo.class);

        if (params == null) {
            throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, String.format("request invalid,request params is [%s]", jsonObject.toString()));
        } else {
            Set<String> brands = params.getBrandId();
            // 子品牌 - 主品牌 映射关系
            LinkedHashMap<String, String> map = getSon2MainBrandMap(brands);
            params.setSon2MainBandId(map);
        }
        return params;
    }

    public static Object generatePvdParam(JSONObject jsonObject, Class<?> clazz) {

        JSONObject bodyMsg = jsonObject.getJSONObject(P_BODY);
        JSONObject dimsMsg = bodyMsg.getJSONObject(P_DIMENSIONS);
        JSONObject optionsMsg = bodyMsg.getJSONObject(P_OPTIONS);

        JSONObject conditionMsg = new JSONObject();
        conditionMsg.putAll(dimsMsg);
        if (optionsMsg != null) {
            conditionMsg.putAll(optionsMsg);
        }

        return JSONObject.toJavaObject(conditionMsg, clazz);

    }

    /**
     * 生成查询入参bean
     * @param jsonObject
     * @param clazz
     * @return
     */
    public static Object generateParam(JSONObject jsonObject, Class<?> clazz) {

        JSONObject bodyMsg = jsonObject.getJSONObject(P_BODY);
        JSONObject dimsMsg = bodyMsg.getJSONObject(P_DIMENSIONS);
        JSONObject optionsMsg = bodyMsg.getJSONObject(P_OPTIONS);

        JSONObject conditionMsg = new JSONObject();
        conditionMsg.putAll(dimsMsg);
        if (optionsMsg != null) {
            conditionMsg.putAll(optionsMsg);
        }

        return JSONObject.toJavaObject(conditionMsg, clazz);

    }

    public static FlowParam generateFlowParamParam(JSONObject jsonObject) {

        JSONObject bodyMsg = jsonObject.getJSONObject(P_BODY);
        JSONObject dimsMsg = bodyMsg.getJSONObject(P_DIMENSIONS);
        JSONObject optionsMsg = bodyMsg.getJSONObject(P_OPTIONS);

        JSONObject conditionMsg = new JSONObject();
        conditionMsg.putAll(dimsMsg);
        if(null != optionsMsg)
            conditionMsg.putAll(optionsMsg);

        FlowParam params = JSONObject.toJavaObject(conditionMsg, FlowParam.class);

        if (params != null) {
            Set<String> brands = params.getBrandId();
            LinkedHashMap<String, String> map = getSon2MainBrandMap(brands);
            params.setSon2MainBandId(map);
        }

        return params;

    }

    public static Set<String> generateCols(JSONObject jsonObject) {

        JSONObject bodyMsg = jsonObject.getJSONObject(P_BODY);
        JSONArray indicatorsMsg = bodyMsg.getJSONArray(P_INDICATORS);
        JSONArray attributesMsg = bodyMsg.getJSONArray(P_ATTRIBUTES);

        JSONArray conditionMsg = new JSONArray();
        conditionMsg.addAll(indicatorsMsg);
        if(null != attributesMsg)
            conditionMsg.addAll(attributesMsg);

        Object[] colsArray = conditionMsg.toArray();
        Set<String> cols = new HashSet<>();
        for (Object col : colsArray) {
            cols.add(String.valueOf(col));
        }
        return cols;

    }


    public static TradePageParamVo generateTradePageParam(JSONObject jsonObject) {
        JSONObject bodyMsg = jsonObject.getJSONObject(P_BODY);
        JSONObject dimsMsg = bodyMsg.getJSONObject(P_DIMENSIONS);

        TradePageParamVo params = JSONObject.toJavaObject(dimsMsg, TradePageParamVo.class);
        Integer pageNum = bodyMsg.getInteger(P_PAGE_NUM);
        Integer rowNum = bodyMsg.getInteger(P_ROW_NUM);

        if (pageNum != null) {
            params.setPageNum(pageNum);
        }
        if (rowNum != null) {
            params.setRowNum(rowNum);
        }

        if (params != null) {
            Set<String> brands = params.getBrandId();
            LinkedHashMap<String, String> map = getSon2MainBrandMap(brands);
            params.setSon2MainBandId(map);
        }
        return params;
    }

    public static LinkedHashMap<String, String> getSon2MainBrandMap(Set<String> brands) {
        // 子品牌 - 主品牌 映射关系
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();

        for (String mainBrandId : brands) {
            String sonBrands = null;
            String key = P_MAINBRAND + mainBrandId;
            try {
                sonBrands = brandMapper.get(key);
            } catch (Exception e) {
                BrandLog.logError("find brandId err from map:" + key, e);
            }
            if (StringUtils.isEmpty(sonBrands)) {
                BrandLog.logInfo("MainBrand:" + key + " can't find son brand");
            } else {
                List<String> sonBrandIdList = Arrays.asList(sonBrands.split(P_KEY_SPLIT));
                for (String sonBrandId : sonBrandIdList) {
                    map.put(sonBrandId, mainBrandId);
                }
            }
        }
        return map;
    }

}
