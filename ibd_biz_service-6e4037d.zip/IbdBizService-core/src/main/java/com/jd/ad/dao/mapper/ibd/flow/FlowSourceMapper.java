package com.jd.ad.dao.mapper.ibd.flow;

import com.jd.ad.dao.bean.ibd.flow.FlowParam;
import org.springframework.stereotype.Repository;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by dongzhe6 on 2018/4/2.
 * Copyright @ 2004-2018 JD
 */

@Repository
public interface FlowSourceMapper {
    List<LinkedHashMap<String, Object>> getIbdFlowSourceGeneral(FlowParam param);
    List<LinkedHashMap<String, Object>> getIbdFlowSourceGeneralToJudgeChildren(FlowParam param);
    List<LinkedHashMap<String, Object>> exportIbdFlowSourceGeneral(FlowParam param);
    List<LinkedHashMap<String, Object>> getIbdShopFlowSourceGeneral(FlowParam param);
    List<LinkedHashMap<String, Object>> getIbdShopFlowSourceGeneralByShop(FlowParam param);
    List<LinkedHashMap<String, Object>> getIbdShopPageGeneral(FlowParam param);
    List<LinkedHashMap<String, Object>> getIbdShopPageFlow(FlowParam param);
    List<LinkedHashMap<String, Object>> getIbdShopPageFlowByShop(FlowParam param);
}
