package com.jd.ad.service;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.dao.bean.ibd.AbstractParam;
import com.jd.ad.log.BrandLog;
import com.jd.ad.utils.tools.IniReader;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.*;

import static com.jd.ad.utils.common.Protocol.P_BODY;
import static com.jd.ad.utils.common.Protocol.P_DIMENSIONS;


public abstract class BrandService {
    public Map<String, Method> getAllMethods() {
        Map<String, Method> methodMap = new HashMap<>();
        Method[] methods = this.getClass().getDeclaredMethods();
        for (Method method : methods) {
            String methodName = method.getName();
            methodMap.put(methodName, method);
        }
        return methodMap;
    }

    private static final String indicatorFile = "indicator.properties";
    protected static final Properties properties = new Properties();

    static {
        InputStream input = null;
        try {
            input = IniReader.class.getClassLoader().getResourceAsStream(indicatorFile);
            try {
                properties.load(input);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            BrandLog.logError("serviceList.ini load fail"+e.getMessage(), e);
            System.exit(1);
        } finally {
            if(input!=null){
                try {
                    input.close();
                } catch (IOException e) {
                    BrandLog.logError("serviceList.ini load fail"+e.getMessage(), e);
                    System.exit(1);
                }
            }
        }
    }

    protected <E extends AbstractParam> E generateFullParam(JSONObject jsonObject,Class<E> clazz) {
        E parameter = generateParam(jsonObject,clazz);
        List<String> columns = generateColumns();
        parameter.setColumns(columns);
        return parameter;
    }

    protected <E extends AbstractParam> E generateFullParam(JSONObject jsonObject,Class<E> clazz,List<String> columns) {
        E parameter = generateParam(jsonObject,clazz);
        parameter.setColumns(columns);
        return parameter;
    }


    protected <E> E generateParam(JSONObject jsonObject,Class<E> clazz) {
        JSONObject bodyMsg = jsonObject.getJSONObject(P_BODY);
        JSONObject dimsMsg = bodyMsg.getJSONObject(P_DIMENSIONS);
        return JSONObject.toJavaObject(dimsMsg, clazz);
    }

    // parameter需要设置columns属性 重写此方法
    protected List<String> generateColumns(String key){
        List<String> columns = new ArrayList<String>();
        if(properties.containsKey(key)){
            String columnKeys = properties.getProperty(key);
            String[] columnKeysArray = columnKeys.split("_");
            for(String columnKey:columnKeysArray){
                if(properties.containsKey(columnKey)){
                    columns.add(properties.getProperty(columnKey));
                }
            }
        }
        return columns;
    }

    private List<String> generateColumns(){
        return generateColumns(getClass().getSimpleName());
    }
}
