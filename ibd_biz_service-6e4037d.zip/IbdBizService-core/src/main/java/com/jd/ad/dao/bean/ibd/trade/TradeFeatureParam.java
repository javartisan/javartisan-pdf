package com.jd.ad.dao.bean.ibd.trade;

import com.alibaba.fastjson.annotation.JSONField;
import com.jd.ad.dao.bean.ibd.AbstractParam;
import com.jd.ad.dao.bean.ibd.flow.FlowParam;

import java.util.HashSet;
import java.util.Set;


public class TradeFeatureParam extends AbstractParam implements Cloneable{


    // 二级类目编码
    @JSONField(name = "Level2IdxCode")
    private String level2IdxCode;
    // 三级类目编码
    @JSONField(name = "Level3IdxCode")
    private String level3IdxCode;


    public String getLevel2IdxCode(){
        return this.level2IdxCode;
    }

    public void setLevel2IdxCode(String level2IdxCode){
        this.level2IdxCode=  level2IdxCode;
    }

    public String getLevel3IdxCode(){
        return this.level3IdxCode;
    }

    public void setLevel3IdxCode(String level3IdxCode){
        this.level3IdxCode=  level3IdxCode;
    }

    @Override
    public Object clone() {
        TradeFeatureParam param = null;
        try{
            param = (TradeFeatureParam)super.clone();
        }catch(CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return param;
    }


}
