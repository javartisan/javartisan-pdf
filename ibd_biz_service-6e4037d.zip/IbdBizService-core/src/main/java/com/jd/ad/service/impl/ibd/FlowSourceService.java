package com.jd.ad.service.impl.ibd;

import com.alibaba.fastjson.JSONObject;

import com.jd.ad.dao.bean.ibd.flow.FlowParam;
import com.jd.ad.dao.mapper.ibd.flow.FlowSourceMapper;
import com.jd.ad.service.BrandService;
import com.jd.ad.utils.common.transform.impl.TransformForClickHouse;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

/**
 * Created by dongzhe6 on 2018/3/29.
 * Copyright @ 2004-2018 JD
 */
//流量来源 提供 "流量来源概览" "店铺流量来源" "店内浏览概览" "店铺店内浏览" 四个子功能.
@Service
public class FlowSourceService extends BrandService {

    @Resource
    FlowSourceMapper flowSourceMapper;

    //流量来源概览
    public JSONObject getIbdFlowSourceGeneral(JSONObject jsonObject) {
        // 校验时间参数
//        CheckUtils.checkDimensionsTime(jsonObject); TODO
        FlowParam parameter = generateFullParam(jsonObject,FlowParam.class,generateColumns("FlowSourceService_FLow"));
        List<LinkedHashMap<String, Object>> result = flowSourceMapper.getIbdFlowSourceGeneral(parameter);
        return new TransformForClickHouse().transform(result);
    }
    //流量来源概览-获取是否有子节点
    public JSONObject getIbdFlowSourceGeneralToJudgeChildren(JSONObject jsonObject) {
        FlowParam parameter = generateFullParam(jsonObject,FlowParam.class,generateColumns("FlowSourceService_FLow_Children"));
        List<LinkedHashMap<String, Object>> result = flowSourceMapper.getIbdFlowSourceGeneralToJudgeChildren(parameter);
        return new TransformForClickHouse().transform(result);
    }

    //流量来源概览-下载
    public JSONObject exportIbdFlowSourceGeneral(JSONObject jsonObject) {
        // 校验时间参数
        FlowParam parameter = generateFullParam(jsonObject,FlowParam.class,generateColumns("FlowSourceService_FLow"));
        List<LinkedHashMap<String, Object>> result = flowSourceMapper.exportIbdFlowSourceGeneral(parameter);
        return new TransformForClickHouse().transform(result);
    }

    //店铺流量来源 - 店铺+流量来源 级别
    public JSONObject getIbdShopFlowSourceGeneral(JSONObject jsonObject) {
        FlowParam parameter = generateFullParam(jsonObject,FlowParam.class,generateColumns("FlowSourceService_FLow_Shop_Source"));
        List<LinkedHashMap<String, Object>> result = flowSourceMapper.getIbdShopFlowSourceGeneral(parameter);
        return new TransformForClickHouse().transform(result);
    }
    //店铺流量来源 - 店铺 级别
    public JSONObject getIbdShopFlowSourceGeneralByShop(JSONObject jsonObject) {
        FlowParam parameter = generateFullParam(jsonObject,FlowParam.class,generateColumns("FlowSourceService_FLow_Shop"));
        List<LinkedHashMap<String, Object>> result = flowSourceMapper.getIbdShopFlowSourceGeneralByShop(parameter);
        return new TransformForClickHouse().transform(result);
    }

    //店内浏览概览
    public JSONObject getIbdShopPageGeneral(JSONObject jsonObject) {
        FlowParam parameter = generateFullParam(jsonObject,FlowParam.class,generateColumns("FlowSourceService_Page"));
        List<LinkedHashMap<String, Object>> result = flowSourceMapper.getIbdShopPageGeneral(parameter);
        return new TransformForClickHouse().transform(result);
    }

    //店铺店内浏览- 店铺+页面 级别
    public JSONObject getIbdShopPageFlow(JSONObject jsonObject) {
        FlowParam parameter = generateFullParam(jsonObject,FlowParam.class,generateColumns("FlowSourceService_Page"));
        List<LinkedHashMap<String, Object>> result = flowSourceMapper.getIbdShopPageFlow(parameter);
        return new TransformForClickHouse().transform(result);
    }

    //店铺店内浏览 - 店铺 级别
    public JSONObject getIbdShopPageFlowByShop(JSONObject jsonObject) {
        FlowParam parameter = generateFullParam(jsonObject,FlowParam.class,generateColumns("FlowSourceService_Page_Shop"));
        List<LinkedHashMap<String, Object>> result = flowSourceMapper.getIbdShopPageFlowByShop(parameter);
        return new TransformForClickHouse().transform(result);
    }
}
