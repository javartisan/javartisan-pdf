package com.jd.ad.dao.bean.brand.flow;

import com.alibaba.fastjson.annotation.JSONField;
import com.jd.ad.dao.bean.BaseVo;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;

/**
 * Created by lvmeiyu on 2018/3/11
 */

public class FlowParam extends  BaseVo{

    private static final long serialVersionUID = 1L;

    // 开始时间
    @JSONField(name = "STime")
    private String sTime;
    // 结束时间
    @JSONField(name = "ETime")
    private String eTime;
    // 主品牌
    @JSONField(name = "BrandId")
    private Set<String> brandId = new HashSet<String>();
    // 子品牌
    private LinkedHashMap<String, String> son2MainBandId;
    // 三级类目
    @JSONField(name = "ThirdIndId")
    private Set<String> thirdIndId = new HashSet<String>();
    // 终端
    @JSONField(name = "TerminalId")
    private Set<String> terminalId = new HashSet<String>();
    // 店铺白名单
    @JSONField(name = "ShopIdWhite")
    private Set<String> shopIdWhite = new HashSet<String>();
    // 店铺黑名单
    @JSONField(name = "ShopIdBlack")
    private Set<String> shopIdBlack = new HashSet<String>();
    // 店铺类型
    @JSONField(name = "ShopType")
    private Set<String> shopType = new HashSet<String>();
    // 一级流量来源
    @JSONField(name = "FirstSourceId")
    private Set<String> firstSourceId = new HashSet<String>();
    // 二级流量来源
    @JSONField(name = "SecondSourceId")
    private Set<String> secondSourceId = new HashSet<String>();
    // 商品SkuId
    @JSONField(name = "SkuId")
    private String skuId;

    @JSONField(name = "FlagType")
    private String flagType ;

    @JSONField(name = "FlagName")
    private Set<String> flagName= new HashSet<String>();

    @JSONField(name = "FlagValueStatus")
    private Set<String> flagValueStatus= new HashSet<String>();

    // 页数
    @JSONField(name = "PageNum")
    private int pageNum = 1;
    // 显示条数
    @JSONField(name = "RowNum")
    private int rowNum = 20;

    private String selectFirstCols;
    private String selectSecondCols;
    private Set<String> browseCols;
    private Set<String> cartCols;
    private Set<String> dealCols;
    private Set<String> dealColsForDistinct;

    public String getSTime() {
        return sTime;
    }

    public void setSTime(String sTime) {
        this.sTime = sTime;
    }

    public String getETime() {
        return eTime;
    }

    public void setETime(String eTime) {
        this.eTime = eTime;
    }

    public Set<String> getBrandId() {
        return brandId;
    }

    public void setBrandId(Set<String> brandId) {
        this.brandId = brandId;
    }

    public LinkedHashMap<String, String> getSon2MainBandId() {
        return son2MainBandId;
    }

    public void setSon2MainBandId(LinkedHashMap<String, String> son2MainBandId) {
        this.son2MainBandId = son2MainBandId;
    }

    public Set<String> getThirdIndId() {
        return thirdIndId;
    }

    public void setThirdIndId(Set<String> thirdIndId) {
        this.thirdIndId = thirdIndId;
    }

    public Set<String> getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(Set<String> terminalId) {
        this.terminalId = terminalId;
    }

    public Set<String> getShopIdWhite() {
        return shopIdWhite;
    }

    public void setShopIdWhite(Set<String> shopIdWhite) {
        this.shopIdWhite = shopIdWhite;
    }

    public Set<String> getShopIdBlack() {
        return shopIdBlack;
    }

    public void setShopIdBlack(Set<String> shopIdBlack) {
        this.shopIdBlack = shopIdBlack;
    }

    public Set<String> getShopType() {
        return shopType;
    }

    public void setShopType(Set<String> shopType) {
        this.shopType = shopType;
    }

    public Set<String> getFirstSourceId() {
        return firstSourceId;
    }

    public void setFirstSourceId(Set<String> firstSourceId) {
        this.firstSourceId = firstSourceId;
    }

    public Set<String> getSecondSourceId() {
        return secondSourceId;
    }

    public void setSecondSourceId(Set<String> secondSourceId) {
        this.secondSourceId = secondSourceId;
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getFlagType() {
        return flagType;
    }

    public void setFlagType(String flagType) {
        this.flagType = flagType;
    }

    public Set<String> getFlagName() {
        return flagName;
    }

    public void setFlagName(Set<String> flagName) {
        this.flagName = flagName;
    }

    public Set<String> getFlagValueStatus() {
        return flagValueStatus;
    }

    public void setFlagValueStatus(Set<String> flagValueStatus) {
        this.flagValueStatus = flagValueStatus;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getRowNum() {
        return rowNum;
    }

    public void setRowNum(int rowNum) {
        this.rowNum = rowNum;
    }

    public String getSelectFirstCols() {
        return selectFirstCols;
    }

    public void setSelectFirstCols(String selectFirstCols) {
        this.selectFirstCols = selectFirstCols;
    }

    public String getSelectSecondCols() {
        return selectSecondCols;
    }

    public void setSelectSecondCols(String selectSecondCols) {
        this.selectSecondCols = selectSecondCols;
    }

    public Set<String> getBrowseCols() {
        return browseCols;
    }

    public void setBrowseCols(Set<String> browseCols) {
        this.browseCols = browseCols;
    }

    public Set<String> getCartCols() {
        return cartCols;
    }

    public void setCartCols(Set<String> cartCols) {
        this.cartCols = cartCols;
    }

    public Set<String> getDealCols() {
        return dealCols;
    }

    public void setDealCols(Set<String> dealCols) {
        this.dealCols = dealCols;
    }

    public Set<String> getDealColsForDistinct() {
        return dealColsForDistinct;
    }

    public void setDealColsForDistinct(Set<String> dealColsForDistinct) {
        this.dealColsForDistinct = dealColsForDistinct;
    }
}
