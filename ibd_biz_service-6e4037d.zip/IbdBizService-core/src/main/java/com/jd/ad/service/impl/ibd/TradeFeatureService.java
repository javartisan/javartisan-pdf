package com.jd.ad.service.impl.ibd;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.dao.bean.ibd.trade.TradeFeatureParam;
import com.jd.ad.dao.mapper.ibd.trade.TradeFeatureMapper;
import com.jd.ad.service.BrandService;
import com.jd.ad.utils.common.transform.impl.TransformForClickHouse;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.LinkedHashMap;
import java.util.List;


@Service
public class TradeFeatureService extends BrandService {

    @Resource
    TradeFeatureMapper tradeFeatureMapper;

    public JSONObject getIbdTradeCustFeature(JSONObject jsonObject) {
        TradeFeatureParam param = generateFullParam(jsonObject,TradeFeatureParam.class);
        List<LinkedHashMap<String, Object>> result = tradeFeatureMapper.getIbdTradeCustFeature(param);
        return new TransformForClickHouse().transform(result);
    }


    public JSONObject getIbdTradeShopCustFeatureDetail(JSONObject jsonObject) {
        TradeFeatureParam param = generateFullParam(jsonObject,TradeFeatureParam.class);
        List<LinkedHashMap<String, Object>> result = tradeFeatureMapper.getIbdTradeShopCustFeatureDetail(param);
        return new TransformForClickHouse().transform(result);
    }


    public JSONObject getIbdTradeSecondItemFeatureDetail(JSONObject jsonObject) {
        TradeFeatureParam param = generateFullParam(jsonObject,TradeFeatureParam.class);
        List<LinkedHashMap<String, Object>> result = tradeFeatureMapper.getIbdTradeSecondItemFeatureDetail(param);
        return new TransformForClickHouse().transform(result);
    }


    public JSONObject getIbdTradeThirdItemFeatureDetail(JSONObject jsonObject) {
        TradeFeatureParam param = generateFullParam(jsonObject,TradeFeatureParam.class);
        List<LinkedHashMap<String, Object>> result = tradeFeatureMapper.getIbdTradeThirdItemFeatureDetail(param);
        return new TransformForClickHouse().transform(result);
    }

    public JSONObject getIbdTradeBrandFeatureDetail(JSONObject jsonObject) {
        TradeFeatureParam param = generateFullParam(jsonObject,TradeFeatureParam.class);
        List<LinkedHashMap<String, Object>> result = tradeFeatureMapper.getIbdTradeBrandFeatureDetail(param);
        return new TransformForClickHouse().transform(result);
    }


    public JSONObject getIbdTradeShopPaymentFeatureDetail(JSONObject jsonObject) {
        TradeFeatureParam param = generateFullParam(jsonObject,TradeFeatureParam.class);
        List<LinkedHashMap<String, Object>> result = tradeFeatureMapper.getIbdTradeShopPaymentFeatureDetail(param);
        return new TransformForClickHouse().transform(result);
    }

    public JSONObject getIbdTradePaymentFeature(JSONObject jsonObject) {
        TradeFeatureParam param = generateFullParam(jsonObject,TradeFeatureParam.class);
        List<LinkedHashMap<String, Object>> result = tradeFeatureMapper.getIbdTradePaymentFeature(param);
        return new TransformForClickHouse().transform(result);
    }

    public JSONObject getIbdTradeProNumFeature(JSONObject jsonObject) {
        TradeFeatureParam param = generateFullParam(jsonObject,TradeFeatureParam.class);
        List<LinkedHashMap<String, Object>> result = tradeFeatureMapper.getIbdTradeProNumFeature(param);
        return new TransformForClickHouse().transform(result);
    }


    public JSONObject getIbdTradeShopProNumFeatureDetail(JSONObject jsonObject) {
        TradeFeatureParam param = generateFullParam(jsonObject,TradeFeatureParam.class);
        List<LinkedHashMap<String, Object>> result = tradeFeatureMapper.getIbdTradeShopProNumFeatureDetail(param);
        return new TransformForClickHouse().transform(result);
    }

    public JSONObject getIbdTradeSecondItemProNumFeatureDetail(JSONObject jsonObject) {
        TradeFeatureParam param = generateFullParam(jsonObject,TradeFeatureParam.class);
        List<LinkedHashMap<String, Object>> result = tradeFeatureMapper.getIbdTradeSecondItemProNumFeatureDetail(param);
        return new TransformForClickHouse().transform(result);
    }


    public JSONObject getIbdTradeThirdItemProNumFeatureDetail(JSONObject jsonObject) {
        TradeFeatureParam param = generateFullParam(jsonObject,TradeFeatureParam.class);
        List<LinkedHashMap<String, Object>> result = tradeFeatureMapper.getIbdTradeThirdItemProNumFeatureDetail(param);
        return new TransformForClickHouse().transform(result);
    }


    public JSONObject getIbdTradeBrandItemProNumFeatureDetail(JSONObject jsonObject) {
        TradeFeatureParam param = generateFullParam(jsonObject,TradeFeatureParam.class);
        List<LinkedHashMap<String, Object>> result = tradeFeatureMapper.getIbdTradeBrandItemProNumFeatureDetail(param);
        return new TransformForClickHouse().transform(result);
    }

}
