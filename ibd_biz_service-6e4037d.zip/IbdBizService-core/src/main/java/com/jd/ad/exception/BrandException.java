package com.jd.ad.exception;

import com.alibaba.fastjson.JSONObject;

import static com.jd.ad.utils.common.Protocol.*;

public abstract class BrandException extends RuntimeException{
    public String errCode;
    public String errorMsg;

    public BrandException(String errCode,String errorMsg)  {
        super(errorMsg);
        this.errCode = errCode;
        this.errorMsg = errorMsg;
    }
    public JSONObject returnJson() {
        JSONObject errorJson = new JSONObject();
        final JSONObject header = new JSONObject();
        header.put(P_CODE, this.errCode);
        header.put(P_DESC,  this.getMessage());
        errorJson.put(P_HEADER,header);
        return errorJson;
    }
}
