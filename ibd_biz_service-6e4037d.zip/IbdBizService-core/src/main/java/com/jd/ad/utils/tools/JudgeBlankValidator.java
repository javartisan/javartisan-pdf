package com.jd.ad.utils.tools;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.exception.impl.ErrorEnum;
import com.jd.ad.log.BrandLog;
import com.jd.ad.utils.common.Protocol;
import com.jd.bdp.ard.cache.spring.ResultValidator;

/**
 * Created by lvmeiyu on 2018/1/22
 */


public class JudgeBlankValidator implements ResultValidator {
    @Override
    public boolean validate(Object returnObj) {

        try {
            JSONObject json =(JSONObject)JSONObject.toJSON(returnObj);
            int size = json.getInteger(Protocol.P_SIZE);
            if (size == 0) {
                return false;
            }
        } catch (Exception e) {
            BrandLog.logError(ErrorEnum.DATA_Cache_ERROR.desc, e);
            return false;
        }
        return true;

    }


}
