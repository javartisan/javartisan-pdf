package com.jd.ad.utils.common;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.exception.impl.ErrorEnum;
import com.jd.ad.exception.impl.ValidateException;
import com.jd.ad.log.BrandLog;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import static com.jd.ad.utils.common.Protocol.*;

/**
 * Created by lvmeiyu on 2018/1/19
 */

public class CheckUtils {

    public static String format = "yyyy-MM-dd";

    public static void checkDimensionsTime(JSONObject req) {
        JSONObject dimMsg = req.getJSONObject(P_BODY).getJSONObject(P_DIMENSIONS);
        // 检查时间是否合法
        String sTime = dimMsg.getString(DimensionList.STIME);
        String eTime = dimMsg.getString(DimensionList.ETIME);
        checkDimensionsTime(sTime, eTime);
    }

    /**
     * 校验时间是否合法
     *
     * @param sTime
     * @param eTime
     */
    public static void checkDimensionsTime(String sTime, String eTime) {
        // 检查时间是否合法
        if (StringUtils.isEmpty(sTime) || StringUtils.isEmpty(eTime)) {
            throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, String.format("request STime or ETime is invalid "));
        } else {
            SimpleDateFormat formater = new SimpleDateFormat(format);
            try {
                long startDay = formater.parse(sTime).getTime();
                long endDay = formater.parse(eTime).getTime();
                long diff = (endDay - startDay) / (1000 * 60 * 60 * 24);
                if (diff > 31) {
                    throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, String.format("request time > 31 day "));
                }
                if (diff < 0) {
                    throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, String.format("request sTime > eTime "));
                }
            } catch (ParseException e) {
                e.printStackTrace();
                BrandLog.logError(ErrorEnum.BAD_REQ_PARAM.code + "request time format invalid ", e);
                throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, String.format("request time format invalid "));
            }
        }
    }

}
