package com.jd.ad.utils.tools;

import com.jd.ad.service.BrandService;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Component
public class SpringConfigTool implements ApplicationContextAware {// extends ApplicationObjectSupport{

    private static ApplicationContext ac = null;

    public void setApplicationContext(ApplicationContext applicationContext)throws BeansException {
        ac = applicationContext;
    }

    public synchronized static Object getBean(String beanName) {
        return ac.getBean(beanName);
    }

    public synchronized static Map<String,BrandService> getBrandServices() {
        return ac.getBeansOfType(BrandService.class);
    }
}
