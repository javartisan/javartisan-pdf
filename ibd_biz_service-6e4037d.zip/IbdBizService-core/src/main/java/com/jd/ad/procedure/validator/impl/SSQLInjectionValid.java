package com.jd.ad.procedure.validator.impl;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.exception.impl.ErrorEnum;
import com.jd.ad.exception.impl.ValidateException;
import com.jd.ad.log.BrandLog;
import com.jd.ad.procedure.validator.Validator;
import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

import static com.jd.ad.utils.common.Protocol.P_BODY;

/**
 * Created by lvmeiyu on 2018/2/26
 */
@Component
public class SSQLInjectionValid implements Validator {

    private static String reg = "(?:')|(?:--)|(/\\*(?:.|[\\n\\r])*?\\*/)|"
            + "(\\b(select|update|union|and|or|delete|insert|trancate|char|into|substr|ascii|declare|exec|master|into|drop|execute)\\b)";

    private static Pattern sqlPattern = Pattern.compile(reg, Pattern.CASE_INSENSITIVE);

    @Override
    public void validate(JSONObject req) throws Exception {

        JSONObject body = req.getJSONObject(P_BODY);
        if (body != null) {
            String bodyStr = body.toJSONString();
            boolean isValid = isValidSqlParam(bodyStr);
            if (!isValid) {
                throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, String.format("request params is invalid for sqlCheck，request params is [%s]", P_BODY, req));
            }
        }
    }

    /**
     * 防止sql依赖注入检查
     *
     * @param str
     * @return
     */
    private static boolean isValidSqlParam(String str) {
        if (sqlPattern.matcher(str).find()) {
            BrandLog.logError("未能通过防sql注入检查：str=" + str);
            return false;
        }
        return true;
    }

}
