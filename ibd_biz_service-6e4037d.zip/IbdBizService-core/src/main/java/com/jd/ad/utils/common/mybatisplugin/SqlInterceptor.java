package com.jd.ad.utils.common.mybatisplugin;

import java.lang.reflect.Field;
import java.sql.Statement;
import java.util.List;
import java.util.Properties;

import com.jd.ad.log.BrandLog;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.ParameterMapping;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Plugin;
import org.apache.ibatis.plugin.Signature;
import org.apache.ibatis.session.ResultHandler;

/**
 * Sql执行记录拦截器
 */
@Intercepts(@Signature(type = StatementHandler.class, method = "query",
        args = {Statement.class, ResultHandler.class}))
public class SqlInterceptor implements Interceptor {
    private Properties properties;

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        Object target = invocation.getTarget();

        long startTime = System.currentTimeMillis();
        StatementHandler statementHandler = (StatementHandler) target;
        try {
            return invocation.proceed();
        } finally {
            long endTime = System.currentTimeMillis();
            long sqlCost = endTime - startTime;

            BoundSql boundSql = statementHandler.getBoundSql();

            // 格式化Sql语句，去除换行符，替换参数
            String sql = formatSql(boundSql);

            BrandLog.logInfo("QuerySQL：[" + sql + "] 执行耗时[" + sqlCost + "ms]");
        }
    }

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    @Override
    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    @SuppressWarnings("unchecked")
    private String formatSql(BoundSql boundSql) {

        String sql = boundSql.getSql();
        Object parameterObject = boundSql.getParameterObject();
        List<ParameterMapping> parameterMappingList = boundSql.getParameterMappings();

        // 输入sql字符串空判断
        if (sql == null || sql.length() == 0) {
            return "";
        }

        // 美化sql
        sql = sql.replaceAll("[\\s\n ]+", " ");

        // 不传参数的场景，直接把Sql美化一下返回出去
        if (parameterObject == null || parameterMappingList == null || parameterMappingList.size() == 0) {
            return sql;
        }

        // 定义一个没有替换过占位符的sql，用于出异常时返回
        String sqlWithoutReplacePlaceholder = sql;

        try {
            if (parameterMappingList != null) {
                Class<?> parameterObjectClass = parameterObject.getClass();

                for (ParameterMapping parameterMapping : parameterMappingList) {
                    String propertyValue = null;
                    // 基本数据类型或者基本数据类型的包装类，直接toString即可获取其真正的参数值，其余直接取paramterMapping中的property属性即可
                    if (isPrimitiveOrPrimitiveWrapper(parameterObjectClass)) {
                        propertyValue = parameterObject.toString();
                    } else {
                        String propertyName = parameterMapping.getProperty();

                        Object value = boundSql.getAdditionalParameter(propertyName);
                        if (value == null) {
                            Field field = parameterObjectClass.getDeclaredField(propertyName);
                            // 要获取Field中的属性值，这里必须将私有属性的accessible设置为true
                            field.setAccessible(true);
                            value = field.get(parameterObject);
                        }
                        propertyValue = String.valueOf(value);
                        if (parameterMapping.getJavaType().isAssignableFrom(String.class)) {
                            propertyValue = "\"" + propertyValue + "\"";
                        }
                    }
                    sql = sql.replaceFirst("\\?", propertyValue);
                }
            }
        } catch (Exception e) {
            // 占位符替换过程中出现异常，则返回没有替换过占位符但是格式美化过的sql
            return sqlWithoutReplacePlaceholder;
        }

        return sql;
    }


    /**
     * 是否基本数据类型或者基本数据类型的包装类
     */
    private boolean isPrimitiveOrPrimitiveWrapper(Class<?> parameterObjectClass) {
        return parameterObjectClass.isPrimitive() ||
                (parameterObjectClass.isAssignableFrom(Byte.class) || parameterObjectClass.isAssignableFrom(Short.class) ||
                        parameterObjectClass.isAssignableFrom(Integer.class) || parameterObjectClass.isAssignableFrom(Long.class) ||
                        parameterObjectClass.isAssignableFrom(Double.class) || parameterObjectClass.isAssignableFrom(Float.class) ||
                        parameterObjectClass.isAssignableFrom(Character.class) || parameterObjectClass.isAssignableFrom(Boolean.class));
    }


}