package com.jd.ad.dao.mapper.ibd.flow;

import com.jd.ad.dao.bean.ibd.flow.FlowParam;
import org.springframework.stereotype.Repository;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by dongzhe6 on 2018/4/2.
 * Copyright @ 2004-2018 JD
 */
@Repository
public interface FlowKeywordMapper {
    List<LinkedHashMap<String, Object>> getIbdFlowKeywordGeneral(FlowParam param);
    List<LinkedHashMap<String, Object>> getIbdShopFlowKeyword(FlowParam param);
}
