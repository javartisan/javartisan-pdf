package com.jd.ad.utils.tools;

import com.jd.ad.log.BrandLog;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Properties;

public class IniReader {
    static HashMap<String, Properties> sections = new HashMap<String, Properties>();
    private static transient String currentSecion;
    private static transient Properties current;
    static final String iniFile = "serviceList.ini";

    public static HashMap getSections() {
        return sections;
    }

    private IniReader(){

    }

    static{

        try {
            InputStream input = IniReader.class.getClassLoader().getResourceAsStream(iniFile);
            InputStreamReader isr = new InputStreamReader(input, "UTF-8");
            BufferedReader reader = new BufferedReader(isr);
            read(reader);
            reader.close();
        } catch (Exception e) {
            BrandLog.logError("serviceList.ini load fail"+e.getMessage(), e);
            System.exit(1);
        }
    }



    /**
     * 读取文件
     *
     * @param reader
     * @throws IOException
     */
    protected static void read(BufferedReader reader) throws IOException {
        String line;
        while ((line = reader.readLine()) != null) {
            parseLine(line);
        }
    }

    /**
     * 解析配置文件行
     *
     * @param line
     */
    @SuppressWarnings("unchecked")
    protected static void parseLine(String line) {
        line = line.trim();
        if (line.matches("\\[.*\\]")) {
            currentSecion = line.replaceFirst("\\[(.*)\\]", "$1");
            current = new Properties();
            sections.put(currentSecion, current);
        } else if (line.matches(".*=.*")) {
            if (current != null) {
                int i = line.indexOf('=');
                String name = line.substring(0, i);
                String value = line.substring(i + 1);
                current.setProperty(name, value);
            }
        }
    }

    /**
     * 获取值
     *
     * @param section
     * @param name
     * @return
     */
    public String getValue(String section, String name) {
        Properties p = (Properties) sections.get(section);
        if (p == null) {
            return null;
        }
        String value = p.getProperty(name);
        return value;
    }

    /**
     * 是否包含key
     *
     * @param section
     * @param key
     * @return
     */
    public boolean containsKey(String section, String key) {
        Properties p = (Properties) sections.get(section);
        return p.contains(key);
    }
}
