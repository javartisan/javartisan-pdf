package com.jd.ad.utils.common;


/**
 *
 */
public interface Protocol {

    public static final String GLOBAL_APP_KEY = "BRAND";

    /**
     * 数据服务的服务名称，如：jd.udp.ad.promotion
     */
    public final static String P_SERVICENAME = "serviceName";

    /**
     * 当前授权用户的PIN信息，来源于统一身份认证中心.
     */
    public final static String P_SESSIONKEY = "session";

    /**
     * 统计指标信息.
     */
    public final static String P_INDICATORS = "indicators";
    
    public final static String P_ATTRIBUTES = "attributes";

    /**
     * 统计维度信息.
     */
    public final static String P_DIMENSIONS = "dimensions";

    public final static String P_OPTIONS = "options";

    /**
     * 消息头常量.
     */
    public final static String P_HEADER = "header";

    /**
     * 消息体常量.
     */
    public final static String P_BODY = "body";

    /**
     * 客户端应用标识，用于表示与数据服务交互的应用信息.
     */
    public final static String P_APPKEY = "appkey";

    /**
     * 消息头中的错误码信息.
     */
    public final static String P_CODE = "code";

    /**
     * 消息头中错误码对应的描述信息.
     */
    public final static String P_DESC = "desc";

    /**
     * 返回客户端的统计数据集.
     */
    public final static String P_DATA = "data";

    /**
     * 数据集大小
     */
    public final static String P_SIZE = "size";

    /**
     * data meta info
     */
    public final static String P_META = "meta";

    public final static String P_META_INDEX = "metaIndex";
    
    public final static String P_DATA_STATUS = "dataStatus";

    public final static String P_TIMESTAMP = "timestamp";

    public final static String P_DI = "di";

    public final static String P_TYPE = "type";
    /**
     * value
     */
    public final static String P_VALUE = "value";
    
    public final static String P_VALUES = "values";
    
    /**
     * 分页查询初始值
     */
    public final static String P_PAGE_NUM = "pageNum";
    
    /**
     * 分页查询size
     */
    public final static String P_ROW_NUM = "rowNum";

    /**
     * 排序
     */
    public final static String P_ORDER = "order";

    public static final String P_KEY_SPLIT = "_";

    /**
     * 主品牌
     */
    public static final String P_MAINBRAND = "MAIN_BRAND_";

}
