package com.jd.ad.conf;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class BrandConf {
    private static Properties brandLogProp = new Properties();

    private BrandConf() {}

    static  {
        try {
            InputStream brandLogStream = BrandConf.class.getResourceAsStream("/BrandLog.properties");
            brandLogProp.load(brandLogStream);
            System.out.println("BrandLog.properties load success!");
        } catch (IOException e) {
            System.out.println("BrandLog.properties load failed!");
            e.printStackTrace();
        }
    }

    public static Properties getBrandLogProp() {
        return brandLogProp;
    }
}
