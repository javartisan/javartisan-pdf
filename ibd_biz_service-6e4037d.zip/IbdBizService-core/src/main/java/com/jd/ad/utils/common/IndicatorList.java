package com.jd.ad.utils.common;

/**
 * Created by lvmeiyu on 2018/1/4
 */

public class IndicatorList {

    // 成交订单数
    public static final String DEAL_NUM = "DealNum";
    //成交金额
    public static final String DEAL_AMT = "DealAmt";
    //  成交客单价
    public static final String CUST_PRICE_AVG = "CustPriceAvg";
    //成交人数
    public static final String DEAL_USER = "DealUser";
    //成交销量
    public static final String DEAL_SALES_VOL = "DealSalesVol";
    //成交转化率
    public static final String CUST_RATE = "CustRate";
    //  访客数
    public static final String UV = "UV";
    // 浏览量
    public static final String PV = "PV";
}
