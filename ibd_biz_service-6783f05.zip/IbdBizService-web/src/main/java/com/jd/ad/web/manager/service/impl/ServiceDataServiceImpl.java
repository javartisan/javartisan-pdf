package com.jd.ad.web.manager.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.utils.common.bean.ServiceBean;
import com.jd.ad.utils.managers.ServiceListManager;
import com.jd.ad.web.manager.service.ServiceDataService;

import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;


@Component("serviceDataService")
public class ServiceDataServiceImpl implements ServiceDataService {
    @Resource
    ServiceListManager serviceListManager;

    public JSONObject queryService(ServiceBean serviceBean) {

//        Pageable pageable = new PageRequest(serviceBean.getPage() == null ? 0 : serviceBean.getPage() - 1, serviceBean.getRows() == null ? 100 : serviceBean.getRows());
//
//        List<ServiceBean> list = serviceListManager.getServiceMap(serviceBean.getServiceName());
//
//        long count = list.size();
//        PageImpl page = new PageImpl<ServiceBean>(list, pageable, count);
//        JSONObject obj = AjaxUtil.jqGridJson(page);
        return null;
    }

}
