package com.jd.ad.web.manager.service;


import com.alibaba.fastjson.JSONObject;
import com.jd.ad.utils.common.bean.ServiceBean;

public interface ServiceDataService {
	
	public JSONObject queryService(ServiceBean serviceBean);

}
