package com.jd.ad.web.controller;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.facade.IbdBizService;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;



@Controller
public class TestController {

    @ResponseBody
    @RequestMapping("/hello")
    public String hello(
            @RequestParam(value = "name", required = false, defaultValue = "default value")
                    String name) {

        return "service:" + name;
    }

    @Resource
    IbdBizService ibdBizService;

    @ResponseBody
    @RequestMapping("/testTradeFeature")
    public String testTradeFeature(@RequestParam(value = "shopId", required = false, defaultValue = "")
                                          String shopId,String serviceName) {
        String req = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdTradeCustFeature\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"201802\",\"LogicalEndTime\":\"201802\",\"ProcessTime\":\"2018-02-23\",\"ShopId\":[\"10026\", \"10126\", \"10144\"],\"ProcessEndTime\":\"2018-02-23\",\"ChannelId\":\"99\"},\"indicators\":[]}}";
        req = req.replace("getIbdTradeCustFeature",serviceName);
        JSONObject json  = JSONObject.parseObject(req);
        return ibdBizService.fetchJsonData(json).toJSONString();
    }


    @ResponseBody
    @RequestMapping("/getIbdFlowSourceGeneral/{id}")
    public String getIbdFlowSourceGeneral(@PathVariable("id") String id) {
        System.out.println("id:"+id);
        //无id
        String req_0 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdFlowSourceGeneral\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180224\",\"LogicalEndTime\":\"20180224\",\"ProcessTime\":\"2018-02-24\",\"ShopId\":[\"35324\"],\"ChannelId\":\"99\",\"Limit\":2000,\"OrderBy\":[\"UV\"],\"Order\":\"desc\"},\"indicators\":[]}}";
        //id 1
        String req_1 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdFlowSourceGeneral\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180224\",\"LogicalEndTime\":\"20180224\",\"ProcessTime\":\"2018-02-24\",\"ShopId\":[\"35324\"],\"ChannelId\":\"99\",\"Limit\":2000,\"Level1SourceId\":[\"2\"],\"OrderBy\":[\"UV\"],\"Order\":\"desc\"},\"indicators\":[]}}";
        //id 2
        String req_2 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdFlowSourceGeneral\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180224\",\"LogicalEndTime\":\"20180224\",\"ProcessTime\":\"2018-02-24\",\"ShopId\":[\"35324\"],\"ChannelId\":\"99\",\"Limit\":2000,\"Level1SourceId\":[\"2\"],\"Level2SourceId\":[\"202\"],\"OrderBy\":[\"UV\"],\"Order\":\"desc\"},\"indicators\":[]}}";

        JSONObject json = null;
        if(StringUtils.isEmpty(id)||id.equals("0")){
            json = JSONObject.parseObject(req_0);
        }else if (id.equals("1")){
            json = JSONObject.parseObject(req_1);
        }else if (id.equals("2")){
            json = JSONObject.parseObject(req_2);
        }

        return ibdBizService.fetchJsonData(json).toJSONString();
    }

    @ResponseBody
    @RequestMapping("/getIbdFlowSourceGeneralToJudgeChildren/{id}")
    public String getIbdFlowSourceGeneralToJudgeChildren(@PathVariable("id") String id) {
        System.out.println("id:"+id);
        //无id
        String req_0 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdFlowSourceGeneralToJudgeChildren\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180224\",\"LogicalEndTime\":\"20180224\",\"ProcessTime\":\"2018-02-24\",\"ShopId\":[\"35324\"],\"ChannelId\":\"99\",\"Limit\":2000},\"indicators\":[]}}";
        //id 1
        String req_1 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdFlowSourceGeneralToJudgeChildren\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180224\",\"LogicalEndTime\":\"20180224\",\"ProcessTime\":\"2018-02-24\",\"ShopId\":[\"35324\"],\"ChannelId\":\"99\",\"Limit\":2000,\"Level1SourceId\":[\"2\"]},\"indicators\":[]}}";

        JSONObject json = null;
        if(StringUtils.isEmpty(id)||id.equals("0")){
            json = JSONObject.parseObject(req_0);
        }else if (id.equals("1")){
            json = JSONObject.parseObject(req_1);
        }

        return ibdBizService.fetchJsonData(json).toJSONString();
    }

    @ResponseBody
    @RequestMapping("/exportIbdFlowSourceGeneral")
    public String exportIbdFlowSourceGeneral() {
        String req = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"exportIbdFlowSourceGeneral\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180224\",\"LogicalEndTime\":\"20180224\",\"ProcessTime\":\"2018-02-24\",\"ShopId\":[\"35324\"],\"ChannelId\":\"99\",\"Limit\":2000,\"OrderBy\":[\"UV\"],\"Order\":\"desc\"},\"indicators\":[]}}";
        JSONObject json  = JSONObject.parseObject(req);
        return ibdBizService.fetchJsonData(json).toJSONString();
    }

    @ResponseBody
    @RequestMapping("/getIbdShopFlowSourceGeneral")
    public String getIbdShopFlowSourceGeneral() {
        String req = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdShopFlowSourceGeneral\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180304\",\"LogicalEndTime\":\"20180304\",\"ProcessTime\":\"2018-03-04\",\"ShopId\":[\"1000072759\",\"1000097810\"],\"ChannelId\":\"2\",\"Limit\":2000,\"OrderBy\":[\"UV\"],\"Order\":\"desc\"},\"indicators\":[]}}";
        JSONObject json  = JSONObject.parseObject(req);
        return ibdBizService.fetchJsonData(json).toJSONString();
    }

    @ResponseBody
    @RequestMapping("/getIbdShopPageGeneral")
    public String getIbdShopPageGeneral() {
        String req = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdShopPageGeneral\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180224\",\"LogicalEndTime\":\"20180224\",\"ProcessTime\":\"2018-02-24\",\"ShopId\":[\"35324\"],\"ChannelId\":\"1\",\"Limit\":2000,\"OrderBy\":[\"UV\"],\"Order\":\"desc\"},\"indicators\":[]}}";
        JSONObject json  = JSONObject.parseObject(req);
        return ibdBizService.fetchJsonData(json).toJSONString();
    }

    @ResponseBody
    @RequestMapping("/getIbdShopPageFlow")
    public String getIbdShopPageFlow() {
        String req = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdShopPageFlow\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180304\",\"LogicalEndTime\":\"20180304\",\"ProcessTime\":\"2018-03-04\",\"ShopId\":[\"1000072759\",\"1000097810\"],\"ChannelId\":\"2\",\"Limit\":2000,\"OrderBy\":[\"UV\"],\"Order\":\"desc\"},\"indicators\":[]}}";
        JSONObject json  = JSONObject.parseObject(req);
        return ibdBizService.fetchJsonData(json).toJSONString();
    }

    @ResponseBody
    @RequestMapping("/getProductDetail/{id}")
    public String getProductDetail(@PathVariable("id") String id) {
        System.out.println("id:"+id);
        //无i
        String req_0 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdCommoditySpuDetail\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180405\",\"LogicalEndTime\":\"20180405\",\"ProcessTime\":\"2018-04-05\",\"ProcessEndTime\":\"2018-04-05\",\"ShopId\":[\"35324\"],\"ChannelId\":\"99\",\"Limit\":2000,\"OrderBy\":[\"OrdAmt\"],\"Order\":\"desc\"},\"indicators\":[]}}";
        //id 1
        String req_1 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdCommoditySkuDetail\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180405\",\"LogicalEndTime\":\"20180405\",\"ProcessTime\":\"2018-04-05\",\"ProcessEndTime\":\"2018-04-05\",\"ShopId\":[\"35324\"],\"ChannelId\":\"99\",\"Limit\":2000,\"Level1SourceId\":[\"2\"],\"OrderBy\":[\"OrdAmt\"],\"Order\":\"desc\"},\"indicators\":[]}}";

        JSONObject json;
        if(id.equals("0")){
            json = JSONObject.parseObject(req_0);
        }else{
            json = JSONObject.parseObject(req_1);
        }
        return ibdBizService.fetchJsonData(json).toJSONString();
    }

    @ResponseBody
    @RequestMapping("/getShopRel/{id}")
    public String getShopRel(@PathVariable("id") String id) {
        System.out.println("id:"+id);
        //无i
        String req_0 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getBrandList\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180405\",\"LogicalEndTime\":\"20180405\",\"ProcessTime\":\"2018-04-05\",\"ShopId\":[\"35324\"]},\"indicators\":[]}}";
        //id 1
        String req_1 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getSectionList\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180405\",\"LogicalEndTime\":\"20180405\",\"ProcessTime\":\"2018-04-05\",\"ShopId\":[\"35324\"]},\"indicators\":[]}}";

        JSONObject json;
        if(id.equals("0")){
            json = JSONObject.parseObject(req_0);
        }else{
            json = JSONObject.parseObject(req_1);
        }
        return ibdBizService.fetchJsonData(json).toJSONString();
    }

    @ResponseBody
    @RequestMapping(value = "/getIbdFlowKeyword/{id}", produces = "application/json; charset=utf-8")
    public String getIbdFlowKeyword(@PathVariable("id") String id) {
        System.out.println("id:"+id);
        //无i
        String req_1 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdFlowKeywordGeneral\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"201804\",\"LogicalEndTime\":\"201804\",\"ProcessTime\":\"2018-04-17\",\"ShopId\":[\"594286\"],\"ChannelId\":\"20\",\"Limit\":2000,\"OrderBy\":[\"UV\"],\"Order\":\"desc\"},\"indicators\":[]}}";
        //id 1
        String req_2 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdShopFlowKeyword\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"201802\",\"LogicalEndTime\":\"201802\",\"ProcessTime\":\"2018-02-03\",\"ShopId\":[\"624776\"],\"ChannelId\":\"3\",\"Limit\":2000,\"OrderBy\":[\"UV\"],\"Order\":\"desc\"},\"indicators\":[]}}";

        String req_3 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getUVIncreaseRateData\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"201802\",\"LogicalEndTime\":\"201802\",\"ProcessTime\":\"2018-02-03\",\"ShopId\":[\"624776\"],\"ChannelId\":\"3\",\"Limit\":2000, \"Keyword\":[\"普提子项链\", \"金刚\"]},\"indicators\":[]}}";

        String req_4 = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getShopUVIncreaseRateData\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"201802\",\"LogicalEndTime\":\"201802\",\"ProcessTime\":\"2018-02-03\",\"ShopId\":[\"624776\"],\"ChannelId\":\"3\",\"Limit\":2000,\"ShopIdKeyword\":[{\"keyword\": \"普提子项链\", \"shopId\": \"74952\"}, {\"keyword\": \"金刚\", \"shopId\": \"74952\"}]},\"indicators\":[]}}";

        JSONObject json;
        if(id.equals("1")){
            json = JSONObject.parseObject(req_1);
        }else if (id.equals("2")){
            json = JSONObject.parseObject(req_2);
        }else if (id.equals("3")){
            json = JSONObject.parseObject(req_3);
        }else{
            json = JSONObject.parseObject(req_4);
        }
        return ibdBizService.fetchJsonData(json).toJSONString();
    }

    @ResponseBody
    @RequestMapping("/testclickHouseService")
    public String testService(
            @RequestParam(value = "shopId", required = false, defaultValue = "")
                    String shopId,String serviceName) {
        String req = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getBrandTradeOverview\"},\"body\":{\"dimensions\":{\"ThirdIndId\":[\"1323\",\"2323\"],\"ETime\":\"20171206\",\"STime\":\"20171206\",\"TerminalId\":[\"1\",\"2\"],\"BrandId\":[\"10026322\",\"310593222\"],\"ShopId\":[\"10026\",\"31059\"]}}}";
        req = req.replace("31059", shopId);
        req = req.replace("getBrandTradeOverview",serviceName);

        JSONObject json = JSONObject.parseObject(req);
        return ibdBizService.fetchJsonData(json).toJSONString();
    }

    @ResponseBody
    @RequestMapping(value="/testBiz", method = { RequestMethod.POST, RequestMethod.GET },produces = {"application/json;charset=UTF-8"})
    public String testBiz(String req) {
        JSONObject json = JSONObject.parseObject(req);
        return ibdBizService.fetchJsonData(json).toJSONString();
    }

    public static void main(String[] args) {
        String req = "{\"header\":{\"appkey\":\"BRAND\",\"serviceName\":\"getIbdFlowSourceGeneral\"},\"body\":{\"dimensions\":{\"LogicalStartTime\":\"20180329\",\"LogicalEndTime\":\"20180329\",\"StartTime\":\"2018-03-29\",\"EndTime\":\"2018-03-29\",\"ShopId\":[\"35324\"],\"ChannelId\":[\"99\"],\"PageNum\":1,\"RowNum\":20,\"OrderBy\":[\"level1SourceId\"],\"Order\":\"desc\"},\"indicators\":[\"pv\",\"uv\",\"avgordCustNum\"]}}";
        JSONObject json = JSONObject.parseObject(req);
        System.out.println(json);
    }
}
