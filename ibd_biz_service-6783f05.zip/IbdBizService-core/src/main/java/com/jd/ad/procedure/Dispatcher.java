package com.jd.ad.procedure;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.exception.impl.DispatchException;
import com.jd.ad.exception.impl.ErrorEnum;
import com.jd.ad.log.BrandLog;
import com.jd.ad.utils.managers.SpringContentManager;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;

import static com.jd.ad.utils.common.Protocol.*;

@Component
public class Dispatcher {
    public static final String UMP_APP_NAME = "IbdShopsBizService";

    @Resource
    SpringContentManager scm;
    public JSONObject dispatch(JSONObject json) {
        JSONObject header = json.getJSONObject(P_HEADER);
        String serviceName =  header.getString(P_SERVICENAME);
        CallerInfo info = null;

        if(StringUtils.isEmpty(serviceName)) {
            BrandLog.logError("serviceName is not exits!");
            throw new DispatchException(ErrorEnum.SERVICE_NOT_EXIST.code, "serviceName is not exits!");
        } else {
            try {
                //ServiceName监控注册
                info = Profiler.registerInfo(serviceName, UMP_APP_NAME,true, true);
                //调用相应的Service Method
                return scm.invokeMethod(serviceName, json);
            } catch (Throwable t) {
                //监控异常(可用率)
                Profiler.functionError(info);
                //这里不做统一的异常处理,直接抛出去
                throw t;
            } finally {
                //监控结束标志
                Profiler.registerInfoEnd(info);
            }
        }
    }
}
