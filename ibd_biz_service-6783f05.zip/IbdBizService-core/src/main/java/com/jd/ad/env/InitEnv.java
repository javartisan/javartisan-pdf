package com.jd.ad.env;

import org.springframework.web.context.ContextLoader;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.util.Properties;

public class InitEnv extends ContextLoader implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        final String envProps = "/spring/env.properties";
        final Properties envProperties = new Properties();
        try {
            envProperties.load(getClass().getResourceAsStream(envProps));
        } catch (Exception e) {

        }
        for(String prop: envProperties.stringPropertyNames()) {
            if(null == System.getProperty(prop)) {
                System.setProperty(prop, envProperties.getProperty(prop));
            }
        }
        System.out.println("brand.env is:" + System.getProperty("brand.env"));
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {

    }
}
