package com.jd.ad.dao.mapper.ibd.trade;

import org.springframework.stereotype.Repository;
import java.util.LinkedHashMap;
import java.util.List;
import com.jd.ad.dao.bean.ibd.trade.TradeParam;

/**
 * 交易概况
 */

@Repository
public interface TradeGeneralMapper {

    List<LinkedHashMap<String, Object>> getIbdTradeGeneralOverview(TradeParam param);
    List<LinkedHashMap<String, Object>> getBndTradeGeneralTrend(TradeParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeShopDetail(TradeParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeBrandDetail(TradeParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeSecondItemDetail(TradeParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeThirdItemDetail(TradeParam param);


}
