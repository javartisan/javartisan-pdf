package com.jd.ad.dao.mapper.ibd.trade;

import com.jd.ad.dao.bean.ibd.trade.TradeFeatureParam;
import org.springframework.stereotype.Repository;

import java.util.LinkedHashMap;
import java.util.List;


/**
 * 交易特征
 */

@Repository
public interface TradeFeatureMapper {

    List<LinkedHashMap<String, Object>> getIbdTradeCustFeature(TradeFeatureParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeShopCustFeatureDetail(TradeFeatureParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeSecondItemFeatureDetail(TradeFeatureParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeThirdItemFeatureDetail(TradeFeatureParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeBrandFeatureDetail(TradeFeatureParam param);


    List<LinkedHashMap<String, Object>> getIbdTradePaymentFeature(TradeFeatureParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeShopPaymentFeatureDetail(TradeFeatureParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeProNumFeature(TradeFeatureParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeShopProNumFeatureDetail(TradeFeatureParam param);


    List<LinkedHashMap<String, Object>> getIbdTradeSecondItemProNumFeatureDetail(TradeFeatureParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeThirdItemProNumFeatureDetail(TradeFeatureParam param);

    List<LinkedHashMap<String, Object>> getIbdTradeBrandItemProNumFeatureDetail(TradeFeatureParam param);

}
