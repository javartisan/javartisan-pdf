package com.jd.ad.exception.impl;

import com.jd.ad.exception.BrandException;

public class ValidateException extends BrandException {
    public ValidateException(String errCode,String errorMsg){
        super(errCode,errorMsg);
    }
}
