package com.jd.ad.procedure.validator;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.log.BrandLog;
import com.jd.ad.procedure.validator.impl.SAuthenticationValidator;
import com.jd.ad.procedure.validator.impl.SDimensionValidator;
import com.jd.ad.procedure.validator.impl.SSQLInjectionValid;
import com.jd.ad.procedure.validator.impl.SStrictValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * 消息验证器代理，验证客户端发送的消息报文是否符合约定.
 */
@Component
public class SValidatorProxy {
    @Autowired
    SAuthenticationValidator sstrictValidator;

    @Autowired
    SStrictValidator sauthValidator;

    @Autowired
    SDimensionValidator sdimensionValidator;

    @Autowired
    SSQLInjectionValid ssqlInjectionValid;

    public void validate(JSONObject req) throws Exception {
        BrandLog.logInfo("开启消息验证器链 ...");
        sstrictValidator.validate(req);
        sauthValidator.validate(req);
//        sdimensionValidator.validate(req);
        ssqlInjectionValid.validate(req);
        BrandLog.logInfo("走完链中全部验证器，消息验证结束！");
    }

}
