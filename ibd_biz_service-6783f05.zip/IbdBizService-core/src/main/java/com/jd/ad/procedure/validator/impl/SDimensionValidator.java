package com.jd.ad.procedure.validator.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jd.ad.exception.impl.ErrorEnum;
import com.jd.ad.exception.impl.ValidateException;
import com.jd.ad.procedure.validator.Validator;
import com.jd.ad.utils.common.bean.ServiceBean;
import com.jd.ad.utils.managers.ServiceListManager;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.jd.ad.utils.common.Protocol.*;
import static com.jd.ad.utils.common.Protocol.P_KEY_SPLIT;

/**
 * Created by lvmeiyu on 2018/1/4
 */
@Component
public class SDimensionValidator implements Validator {

    @Resource
    ServiceListManager serviceListManager;

    @Override
    public void validate(JSONObject req) throws Exception {

        try {

            String serviceName = req.getJSONObject(P_HEADER).getString(P_SERVICENAME);
            ServiceBean serviceBean = serviceListManager.getServiceBean(serviceName);
            if (serviceBean != null) {

                // 维度校验
//                String dimensions = serviceBean.getDimensions();
//                JSONObject dimMsg = req.getJSONObject(P_BODY).getJSONObject(P_DIMENSIONS);
//                if ( StringUtils.isEmpty(dimMsg) || StringUtils.isEmpty(dimensions)) {
//                    throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, "no dimensions, check serviceList.ini or reqJSON");
//                }
//
//                Set<String> paramDimSet = dimMsg.keySet();
//                List<String> dimensionList = Arrays.asList(dimensions.split(P_KEY_SPLIT));
//                Set<String> dimensionSet = new HashSet<String>();
//                dimensionSet.addAll(dimensionList);
//                if (!(dimensionSet.containsAll(paramDimSet) && paramDimSet.containsAll(dimensionSet))) {
//                    String errDim = "";
//
//                    if (dimensionSet.size() >= paramDimSet.size()) {
//                        errDim = "lost dimensions:";
//                        for (String dim : dimensionSet) {
//                            if (!paramDimSet.contains(dim)) {
//                                errDim += dim + ",";
//                            }
//                        }
//                    } else {
//                        errDim = "no dimensions:";
//                        for (String dim : paramDimSet) {
//                            if (!dimensionSet.contains(dim)) {
//                                errDim += dim + ",";
//                            }
//                        }
//                    }
//                    throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, "dimensions:" + errDim);
//                }

                // 指标校验
//                String indicators = serviceBean.getIndicators();
//                if (StringUtils.isEmpty(indicators)) {
//                    throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, "no indicators");
//                }
//                List<String> indicatorsList = Arrays.asList(indicators.split(P_KEY_SPLIT));
//                Set<String> indicatorsSet = new HashSet<String>();
//                indicatorsSet.addAll(indicatorsList);
//                JSONArray indMsg = req.getJSONObject(P_BODY).getJSONArray(P_INDICATORS);
//                for (int i = 0; i < indMsg.size(); i++) {
//                    if (!indicatorsSet.contains(indMsg.getString(i))) {
//                        throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, "indicators:" + indMsg.getString(i));
//                    }
//                }

                // 属性校验
                String attributes = serviceBean.getAttributes();
                JSONArray attrMsg = req.getJSONObject(P_BODY).getJSONArray(P_ATTRIBUTES);
                if (null != attrMsg) { //如果没传属性,就不校验了
                    if (StringUtils.isEmpty(attributes) && attrMsg.size() > 0) {
                        throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, "attributes:" + attrMsg.toJSONString());
                    }
                    if (!StringUtils.isEmpty(attributes)) {
                        List<String> attributesList = Arrays.asList(attributes.split(P_KEY_SPLIT));
                        Set<String> attributesSet = new HashSet<String>();
                        attributesSet.addAll(attributesList);

                        for (int i = 0; i < attrMsg.size(); i++) {
                            if (!attributesSet.contains(attrMsg.getString(i))) {
                                throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, "attributes:" + attrMsg.getString(i));
                            }
                        }
                    }
                }

                // 可选项校验
                String options = serviceBean.getOptions();
                JSONObject optionMsg = req.getJSONObject(P_BODY).getJSONObject(P_OPTIONS);
                if (null != optionMsg) {
                    if (StringUtils.isEmpty(options) && optionMsg.keySet().size() > 0) {
                        throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, "options:" + optionMsg.toJSONString());
                    }
                    if (!StringUtils.isEmpty(options)) {
                        List<String> optionsList = Arrays.asList(options.split(P_KEY_SPLIT));
                        Set<String> optionsSet = new HashSet<String>();
                        optionsSet.addAll(optionsList);

                        Set<String> optionParamSet = optionMsg.keySet();

                        if (!optionsSet.containsAll(optionParamSet)) {
                            throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, "options:" + optionMsg.toJSONString());
                        }
                    }
                }
            } else {
                throw new ValidateException(ErrorEnum.SERVICE_NOT_EXIST.code, "service is not exist");
            }

        } catch (Exception e) {
            throw new ValidateException(ErrorEnum.BAD_REQ_PARAM.code, e.getMessage() + String.format(" ,is invalid"));

        }

    }

}
