package com.jd.ad.procedure.validator.impl;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.exception.impl.ErrorEnum;
import com.jd.ad.exception.impl.ValidateException;
import com.jd.ad.procedure.validator.Validator;
import org.springframework.stereotype.Component;

import static com.jd.ad.utils.common.Protocol.*;


/**
 * 接口权限校验
 */
@Component
public class SAuthenticationValidator implements Validator {

    @Override
    public void validate(JSONObject req) {
        JSONObject header = req.getJSONObject(P_HEADER);
        if (header == null || !header.containsKey(P_APPKEY)) {
            throw new ValidateException(ErrorEnum.AUTH_FAILED.code, " appKey must input");
        }
        String appkey = header.getString(P_APPKEY).trim();
        if (appkey == null || !GLOBAL_APP_KEY.equals(appkey)) {
            String errorMsg = "APP[" + appkey + "]没有访问权限";
            throw new ValidateException(ErrorEnum.AUTH_FAILED.code, errorMsg);
        }
    }

}
