package com.jd.ad.dao.mapper.ibd.commodity;

import com.jd.ad.dao.bean.ibd.commodity.CommodityDetailParam;
import org.springframework.stereotype.Repository;

import java.util.LinkedHashMap;
import java.util.List;


@Repository
public interface CommodityDetailMapper {

    List<LinkedHashMap<String, Object>> getIbdCommoditySpuCount(CommodityDetailParam param);
    List<LinkedHashMap<String, Object>> getIbdCommoditySpuDetail(CommodityDetailParam param);

    List<LinkedHashMap<String, Object>> getIbdCommoditySkuCount(CommodityDetailParam param);
    List<LinkedHashMap<String, Object>> getIbdCommoditySkuDetail(CommodityDetailParam param);

}
