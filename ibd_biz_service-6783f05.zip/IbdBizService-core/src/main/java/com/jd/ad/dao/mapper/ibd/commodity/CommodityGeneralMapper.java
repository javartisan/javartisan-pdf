package com.jd.ad.dao.mapper.ibd.commodity;

import com.jd.ad.dao.bean.ibd.commodity.CommodityDetailParam;
import org.springframework.stereotype.Repository;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by dongzhe6 on 2018/4/2.
 * Copyright @ 2004-2018 JD
 */
@Repository
public interface CommodityGeneralMapper {
    List<LinkedHashMap<String, Object>> getIbdSkuCommodityGeneralOverview(CommodityDetailParam param);

    List<LinkedHashMap<String, Object>> getIbdSpuCommodityGeneralOverview(CommodityDetailParam param);

    List<LinkedHashMap<String, Object>> getIbdSkuShopCommodityGeneral(CommodityDetailParam param);

    List<LinkedHashMap<String, Object>> getIbdSpuShopCommodityGeneral(CommodityDetailParam param);

    List<LinkedHashMap<String, Object>> getIbdSkuCommodityTrend(CommodityDetailParam param);

    List<LinkedHashMap<String, Object>> getIbdSpuCommodityTrend(CommodityDetailParam param);

}
