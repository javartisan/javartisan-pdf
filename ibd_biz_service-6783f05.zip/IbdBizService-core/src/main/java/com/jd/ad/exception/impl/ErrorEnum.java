package com.jd.ad.exception.impl;


/**
 * 错误编码以及相应描述说明
 */
public enum ErrorEnum {
    // add
    BAD_REQ_PARAM("1001", " Bad request parameters "),

    ERR_REQ_PATTERN("1010", " data type error "),

    REQ_OVERFLOW("1002", "over request flow"),

    BETWEENVALUE_ERROR("1009", " between value  size illegals"),

    INVALUE_ERROR("1019", "  in value illegal the  value is null "),
    //
    NO_INDICATOR_DIMENSION("1002", "Indicators or Dimensions is not supported"),

    OPERATION_NO_SUPPORTED("1003", "operation is not supported"),

    WHERE_EXPRESSION_SYNTAX("1004", "where condition syntax error"),

    SERVICE_NOT_EXIST("1005", "service is not exist"),

    AUTH_FAILED("2001", "Authentication failed"),

    NO_PERMISSION("2002", "No permission to call this api"),

    EXCP_OCCURRED("5001", "An exception occurred"),

    SYS_ERROR("7001", "An system error occurred"),


    /**
     * For MetaService Errors
     */

    CREATE_EXIST_ERROR("3001", " Data creating exist "),

    DELETE_NOTEXIST_ERROR("3002", " Data deleting not exist "),

    UPDATE_EXIST_ERROR("3003", " Data updating exist "),

    SEARCH_DATA_ERROR("3004", " Encounter an error when searching"),

    PARAM_PROP_ERROR("3005", " Bad bean property "),

    PARAM_VALUE_ERROR("3006", " Bad bean value "),

    AUTH_ERROR("3007", " Encounter an error when authorizing "),

    DATA_TRANSFORM_ERROR("3008", " return data transform error "),

    DATA_QUERY_ERROR("3009", " query data error "),

    /**
     * FOR Cache
     */
    DATA_Cache_ERROR("4001", " Cache validator error ");


    public final String code;

    public final String desc;


    private ErrorEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
