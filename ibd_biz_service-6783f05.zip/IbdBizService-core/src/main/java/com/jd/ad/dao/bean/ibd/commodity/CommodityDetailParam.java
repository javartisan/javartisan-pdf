package com.jd.ad.dao.bean.ibd.commodity;

import com.alibaba.fastjson.annotation.JSONField;
import com.jd.ad.dao.bean.ibd.AbstractParam;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CommodityDetailParam extends AbstractParam implements Cloneable{

    // 二级类目编码
    @JSONField(name = "Level2IdxCode")
    private String level2IdxCode;
    // 三级类目编码
    @JSONField(name = "Level3IdxCode")
    private String level3IdxCode;

    @JSONField(name = "SpuId")
    private Set<String> spuId;

    @JSONField(name = "SkuId")
    private Set<String> skuId;

    public void setSpuId(Set<String> spuId){
        this.spuId = spuId;
    }

    public Set<String> getSpuId() {
        return spuId;
    }

    public void setSkuId(Set<String> skuId) {
        this.skuId = skuId;
    }

    public Set<String> getSkuId() {
        return skuId;
    }

    public String getLevel2IdxCode(){
        return this.level2IdxCode;
    }

    public void setLevel2IdxCode(String level2IdxCode){
        this.level2IdxCode=  level2IdxCode;
    }

    public String getLevel3IdxCode(){
        return this.level3IdxCode;
    }

    public void setLevel3IdxCode(String level3IdxCode){
        this.level3IdxCode=  level3IdxCode;
    }

    @Override
    public Object clone() {
        CommodityDetailParam param = null;
        try{
            param = (CommodityDetailParam)super.clone();
        }catch(CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return param;
    }

}
