package com.jd.ad.exception.impl;

import com.jd.ad.exception.BrandException;

public class DispatchException extends BrandException {

    public DispatchException(String errCode,String errorMsg){
        super(errCode,errorMsg);
    }
}
