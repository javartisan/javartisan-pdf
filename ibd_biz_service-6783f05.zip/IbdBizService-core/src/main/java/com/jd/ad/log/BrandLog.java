package com.jd.ad.log;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BrandLog {

    private static Logger writerLog = LogManager.getLogger("");
    static {
//        PropertyConfigurator.configure(BrandConf.getBrandLogProp());
    }


    /**
     * 三个log函数被哪个类调用，返回类名称
     * @return
     */
    public static String getLogClassName(){
        return "[" + Thread.currentThread().getStackTrace()[3].getClassName() +"]";
    }

    public static void logError(String error, Throwable t) {
        writerLog.error(getLogClassName()+error, t);
    }

    public static void logError(String error) {
        writerLog.error(getLogClassName()+error);
    }

    public static void logInfo(String info) {
        writerLog.info(getLogClassName()+info);
    }

    public static void logWarn(String warn) {
        writerLog.warn(getLogClassName()+warn);
    }

}
