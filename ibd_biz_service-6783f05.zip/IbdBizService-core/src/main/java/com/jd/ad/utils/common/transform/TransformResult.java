package com.jd.ad.utils.common.transform;

/**
 * Created by lvmeiyu on 2018/1/9
 */

public interface TransformResult<I, O> {
     O  transform(I sourceResult);

}
