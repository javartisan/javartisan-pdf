package com.jd.ad.service.impl.ibd;

import com.alibaba.fastjson.JSONObject;
import com.jd.ad.dao.bean.ibd.commodity.CommodityDetailParam;
import com.jd.ad.dao.mapper.ibd.commodity.CommodityDetailMapper;
import com.jd.ad.service.BrandService;
import com.jd.ad.utils.common.transform.impl.TransformForClickHouse;
import com.jd.ad.utils.tools.MultiQueryTool;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.*;

@Service
public class CommodityDetailService extends BrandService {


    @Resource
    CommodityDetailMapper commodityDetailMapper;

    public JSONObject getIbdCommoditySpuCount(JSONObject jsonObject) {
        CommodityDetailParam param = generateParam(jsonObject,CommodityDetailParam.class);
        List<LinkedHashMap<String, Object>> result = commodityDetailMapper.getIbdCommoditySpuCount(param);
        return new TransformForClickHouse().transform(result);
    }

    public JSONObject getIbdCommoditySpuDetail(JSONObject jsonObject) {
        CommodityDetailParam param = generateFullParam(jsonObject,CommodityDetailParam.class, generateColumns("CommodityDetailServiceSpu"));

        List<List<LinkedHashMap<String, Object>>> results = new ArrayList<>();
        List<Set<String>> shopSpilts = MultiQueryTool.split(param.getShopId(), MultiQueryTool.SHOP_ID_SIZE);
        List<Future> futures = new ArrayList<>();
        for (int i = 0; i < shopSpilts.size(); i++) {
            final CommodityDetailParam pieceParam = (CommodityDetailParam) param.clone();
            pieceParam.setShopId(shopSpilts.get(i));
            Future f = MultiQueryTool.CACHE_THREAD_POOL.submit(new Callable<Object>() {
                public List<LinkedHashMap<String, Object>> call() {
                    return commodityDetailMapper.getIbdCommoditySpuDetail(pieceParam);
                }
            });
            futures.add(f);
        }
        for(Future f: futures){
            try{
                results.add((List<LinkedHashMap<String, Object>>)f.get());
            }catch (InterruptedException | ExecutionException e){
                e.printStackTrace();
            }
        }
        // merge, order and cut
        List<LinkedHashMap<String, Object>> result = MultiQueryTool.merge(results, param.getOrderBy(), param.getOrder(), param.getLimit());
        return new TransformForClickHouse().transform(result);
    }

    public JSONObject getIbdCommoditySkuCount(JSONObject jsonObject) {
        CommodityDetailParam param = generateParam(jsonObject,CommodityDetailParam.class);
        List<LinkedHashMap<String, Object>> result = commodityDetailMapper.getIbdCommoditySkuCount(param);
        return new TransformForClickHouse().transform(result);
    }

    public JSONObject getIbdCommoditySkuDetail(JSONObject jsonObject){
        CommodityDetailParam param = generateFullParam(jsonObject,CommodityDetailParam.class, generateColumns("CommodityDetailServiceSku"));

        List<List<LinkedHashMap<String, Object>>> results = new ArrayList<>();
        List<Set<String>> shopSpilts = MultiQueryTool.split(param.getShopId(), MultiQueryTool.SHOP_ID_SIZE);
        List<Future> futures = new ArrayList<>();
        for (int i = 0; i < shopSpilts.size(); i++) {
            final CommodityDetailParam pieceParam = (CommodityDetailParam) param.clone();
            pieceParam.setShopId(shopSpilts.get(i));
            Future f = MultiQueryTool.CACHE_THREAD_POOL.submit(new Callable<Object>() {
                public List<LinkedHashMap<String, Object>> call() {
                    return commodityDetailMapper.getIbdCommoditySkuDetail(pieceParam);
                }
            });
            futures.add(f);
        }
        for(Future f: futures){
            try{
                results.add((List<LinkedHashMap<String, Object>>)f.get());
            }catch (InterruptedException | ExecutionException e){
                e.printStackTrace();
            }
        }

        // merge, order and cut
        List<LinkedHashMap<String, Object>> result = MultiQueryTool.merge(results, param.getOrderBy(), param.getOrder(), param.getLimit());
        return new TransformForClickHouse().transform(result);
    }

}
