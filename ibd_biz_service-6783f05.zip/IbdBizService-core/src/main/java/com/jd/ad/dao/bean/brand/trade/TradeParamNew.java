package com.jd.ad.dao.bean.brand.trade;

import com.alibaba.fastjson.annotation.JSONField;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;

/**
 * Created by lvmeiyu on 2018/3/17
 */

public class TradeParamNew {

    // 开始时间
    @JSONField(name = "STime")
    private String sTime;
    // 结束时间
    @JSONField(name = "ETime")
    private String eTime;
    // 主品牌
    @JSONField(name = "BrandId")
    private Set<String> brandId = new HashSet<String>();
    // 子品牌
    private LinkedHashMap<String, String> son2MainBandId;
    // 三级类目
    @JSONField(name = "ThirdIndId")
    private Set<String> thirdIndId = new HashSet<String>();
    // 终端
    @JSONField(name = "TerminalId")
    private Set<String> terminalId = new HashSet<String>();
    // 店铺白名单
    @JSONField(name = "ShopIdWhite")
    private Set<String> shopIdWhite = new HashSet<String>();
    // 店铺黑名单
    @JSONField(name = "ShopIdBlack")
    private Set<String> shopIdBlack = new HashSet<String>();
    // 店铺类型
    @JSONField(name = "ShopType")
    private Set<String> shopType = new HashSet<String>();
    // 商品SkuId
    @JSONField(name = "SkuId")
    private String skuId;
    // 促销方式（名称）
    @JSONField(name = "SaleName")
    private String saleName;
    // 支付方式（名称）
    @JSONField(name = "PaymentModeDec")
    private String paymentModeDec;
    // 价格带（名称）
    @JSONField(name = "PriceZoneName")
    private String priceZoneName;
    // 页数
    @JSONField(name = "PageNum")
    private int pageNum = 1;
    // 显示条数
    @JSONField(name = "RowNum")
    private int rowNum = 20;
    @JSONField(name = "OrderBy")
    private String orderBy;
    // 要查询的三级类目，用于展示单一类目的趋势图
    @JSONField(name = "QueryThirdIndId")
    private String queryThirdIndId;
    // 要查询的终端，用于展示单一终端的趋势图(由于移动整体的需要，是set类型
    @JSONField(name = "QueryTerminalId")
    private Set<String> queryTerminalId;

    private String selectFirstCols;
    private Set<String> flowCols;
    private Set<String> dealCols;
    private Set<String> cartCols;
    private Set<String> ordCols;
    private Set<String> dealSumCols;
    private Set<String> secondJoinFlowAndCartCols;
    private Set<String> secondJoinOrdAndDealCols;
    private Set<String> firstJoinCols;

    public String getSTime() {
        return sTime;
    }

    public void setSTime(String sTime) {
        this.sTime = sTime;
    }

    public String getETime() {
        return eTime;
    }

    public void setETime(String eTime) {
        this.eTime = eTime;
    }

    public Set<String> getBrandId() {
        return brandId;
    }

    public void setBrandId(Set<String> brandId) {
        this.brandId = brandId;
    }

    public LinkedHashMap<String, String> getSon2MainBandId() {
        return son2MainBandId;
    }

    public void setSon2MainBandId(LinkedHashMap<String, String> son2MainBandId) {
        this.son2MainBandId = son2MainBandId;
    }

    public Set<String> getThirdIndId() {
        return thirdIndId;
    }

    public void setThirdIndId(Set<String> thirdIndId) {
        this.thirdIndId = thirdIndId;
    }

    public Set<String> getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(Set<String> terminalId) {
        this.terminalId = terminalId;
    }

    public Set<String> getShopIdWhite() {
        return shopIdWhite;
    }

    public void setShopIdWhite(Set<String> shopIdWhite) {
        this.shopIdWhite = shopIdWhite;
    }

    public Set<String> getShopIdBlack() {
        return shopIdBlack;
    }

    public void setShopIdBlack(Set<String> shopIdBlack) {
        this.shopIdBlack = shopIdBlack;
    }

    public Set<String> getShopType() {
        return shopType;
    }

    public void setShopType(Set<String> shopType) {
        this.shopType = shopType;
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getSaleName() {
        return saleName;
    }

    public void setSaleName(String saleName) {
        this.saleName = saleName;
    }

    public String getPaymentModeDec() {
        return paymentModeDec;
    }

    public void setPaymentModeDec(String paymentModeDec) {
        this.paymentModeDec = paymentModeDec;
    }

    public String getPriceZoneName() {
        return priceZoneName;
    }

    public void setPriceZoneName(String priceZoneName) {
        this.priceZoneName = priceZoneName;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getRowNum() {
        return rowNum;
    }

    public void setRowNum(int rowNum) {
        this.rowNum = rowNum;
    }

    public String getSelectFirstCols() {
        return selectFirstCols;
    }

    public void setSelectFirstCols(String selectFirstCols) {
        this.selectFirstCols = selectFirstCols;
    }

    public Set<String> getFlowCols() {
        return flowCols;
    }

    public void setFlowCols(Set<String> flowCols) {
        this.flowCols = flowCols;
    }

    public Set<String> getDealCols() {
        return dealCols;
    }

    public void setDealCols(Set<String> dealCols) {
        this.dealCols = dealCols;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public Set<String> getDealSumCols() {
        return dealSumCols;
    }

    public void setDealSumCols(Set<String> dealSumCols) {
        this.dealSumCols = dealSumCols;
    }

    public String getQueryThirdIndId() {
        return queryThirdIndId;
    }

    public void setQueryThirdIndId(String queryThirdIndId) {
        this.queryThirdIndId = queryThirdIndId;
    }

    public Set<String> getQueryTerminalId() {
        return queryTerminalId;
    }

    public void setQueryTerminalId(Set<String> queryTerminalId) {
        this.queryTerminalId = queryTerminalId;
    }

    public Set<String> getCartCols() {
        return cartCols;
    }

    public void setCartCols(Set<String> cartCols) {
        this.cartCols = cartCols;
    }

    public Set<String> getOrdCols() {
        return ordCols;
    }

    public void setOrdCols(Set<String> ordCols) {
        this.ordCols = ordCols;
    }

    public Set<String> getSecondJoinFlowAndCartCols() {
        return secondJoinFlowAndCartCols;
    }

    public void setSecondJoinFlowAndCartCols(Set<String> secondJoinFlowAndCartCols) {
        this.secondJoinFlowAndCartCols = secondJoinFlowAndCartCols;
    }

    public Set<String> getSecondJoinOrdAndDealCols() {
        return secondJoinOrdAndDealCols;
    }

    public void setSecondJoinOrdAndDealCols(Set<String> secondJoinOrdAndDealCols) {
        this.secondJoinOrdAndDealCols = secondJoinOrdAndDealCols;
    }

    public Set<String> getFirstJoinCols() {
        return firstJoinCols;
    }

    public void setFirstJoinCols(Set<String> firstJoinCols) {
        this.firstJoinCols = firstJoinCols;
    }
}
