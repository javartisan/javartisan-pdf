package com.jd.ad.utils.common.bean;

public class BaseModel {
	private Integer limit;

	private Integer start;
	
	//jqGrid自身参数 当前页
	private Integer page = 1;
	//jqGrid自身参数  每页显示多少行
	private Integer rows = 10;
	//jqGrid排序列
	private String sidx;
	
	//jqGrid排序列 升序还是降序
	private String sord;
		
	

	public Integer getLimit() {
		return limit;
	}

	public void setLimit(Integer limit) {
		this.limit = limit;
	}

	public Integer getStart() {
		return start;
	}

	public void setStart(Integer start) {
		this.start = start;
	}

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getRows() {
		return rows;
	}

	public void setRows(Integer rows) {
		this.rows = rows;
	}

	public String getSidx() {
		return sidx;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}

	public String getSord() {
		return sord;
	}

	public void setSord(String sord) {
		this.sord = sord;
	}
}
