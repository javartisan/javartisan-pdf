package com.jd.ad.utils.common;


import java.util.*;

/**
 * Created by lvmeiyu on 2018/1/18
 */

public class ServiceUtil {

    public static LinkedHashMap<String, Object> getMergeMap(LinkedHashMap<String, Object> trade, LinkedHashMap<String, Object> order) {
        LinkedHashMap<String, Object> resMap = new LinkedHashMap<String, Object>();

        if (order != null) {
            order.put(IndicatorList.PV, trade.get(IndicatorList.PV));
            order.put(IndicatorList.UV, trade.get(IndicatorList.UV));
            Double dealUser = (Double) order.get(IndicatorList.DEAL_USER);
            long uv = (Long) trade.get(IndicatorList.UV);
            Double custRate = dealUser / uv;
            order.put(IndicatorList.CUST_RATE, custRate);
            resMap.putAll(order);

        } else {
            trade.put(IndicatorList.DEAL_USER, 0.0);
            trade.put(IndicatorList.CUST_RATE, 0.0);
            trade.put(IndicatorList.CUST_PRICE_AVG, 0.0);
            trade.put(IndicatorList.DEAL_AMT, 0.0);
            trade.put(IndicatorList.DEAL_NUM, 0.0);
            trade.put(IndicatorList.DEAL_SALES_VOL, 0.0);
            resMap.putAll(trade);
        }
        return resMap;
    }

    public static List<LinkedHashMap<String, Object>> getMergeZeroMap(List<LinkedHashMap<String, Object>> tradeList) {
        List<LinkedHashMap<String, Object>> resList = new ArrayList<LinkedHashMap<String, Object>>();

        if (tradeList != null) {
            for (LinkedHashMap<String, Object> map : tradeList) {
                map.put(IndicatorList.DEAL_USER, 0.0);
                map.put(IndicatorList.CUST_RATE, 0.0);
                map.put(IndicatorList.CUST_PRICE_AVG, 0.0);
                map.put(IndicatorList.DEAL_AMT, 0.0);
                map.put(IndicatorList.DEAL_NUM, 0.0);
                map.put(IndicatorList.DEAL_SALES_VOL, 0.0);
                resList.add(map);
            }
        }
        return resList;
    }

}
