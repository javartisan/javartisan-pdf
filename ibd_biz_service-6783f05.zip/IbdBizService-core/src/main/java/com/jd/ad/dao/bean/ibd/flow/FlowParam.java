package com.jd.ad.dao.bean.ibd.flow;

import com.alibaba.fastjson.annotation.JSONField;
import com.jd.ad.dao.bean.ibd.AbstractParam;
import java.util.Set;

/**
 * Created by dongzhe6 on 2018/3/29.
 * Copyright @ 2004-2018 JD
 */
public class FlowParam extends AbstractParam implements Cloneable{

    // 一级流量来源
    @JSONField(name = "Level1SourceId")
    private Set<String> level1SourceId;
    // 二级流量来源
    @JSONField(name = "Level2SourceId")
    private Set<String> level2SourceId;
    // 三级流量来源
    @JSONField(name = "Level3SourceId")
    private Set<String> level3SourceId;
    // 页面类型
    @JSONField(name = "PageType")
    private Set<String> pageType;


    public Set<String> getLevel1SourceId() {
        return level1SourceId;
    }

    public void setLevel1SourceId(Set<String> level1SourceId) {
        this.level1SourceId = level1SourceId;
    }

    public Set<String> getLevel2SourceId() {
        return level2SourceId;
    }

    public void setLevel2SourceId(Set<String> level2SourceId) {
        this.level2SourceId = level2SourceId;
    }

    public Set<String> getLevel3SourceId() {
        return level3SourceId;
    }

    public void setLevel3SourceId(Set<String> level3SourceId) {
        this.level3SourceId = level3SourceId;
    }

    public Set<String> getPageType() {
        return pageType;
    }

    public void setPageType(Set<String> pageType) {
        this.pageType = pageType;
    }

    @Override
    public Object clone() {
        FlowParam param = null;
        try{
            param = (FlowParam)super.clone();
        }catch(CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return param;
    }
}
