package com.jd.ad.exception.impl;

import com.jd.ad.exception.BrandException;

public class ProcessException extends BrandException  {
        public ProcessException(String errCode,String errorMsg){
            super(errCode,errorMsg);
        }
}
