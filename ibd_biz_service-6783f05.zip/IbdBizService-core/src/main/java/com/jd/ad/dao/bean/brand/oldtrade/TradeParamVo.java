package com.jd.ad.dao.bean.brand.oldtrade;

import com.alibaba.fastjson.annotation.JSONField;
import com.jd.ad.dao.bean.BaseVo;

import java.util.*;

/**
 * Created by lvmeiyu on 2018/1/8
 */

public class TradeParamVo extends BaseVo {
    private static final long serialVersionUID = 1L;

    // 开始时间
    @JSONField(name = "STime")
    private String sTime;
    // 结束时间
    @JSONField(name = "ETime")
    private String eTime;
    // 主品牌
    @JSONField(name = "BrandId")
    private Set<String> brandId = new HashSet<String>();
    // 子品牌
    private LinkedHashMap<String, String> son2MainBandId;
    // 类目
    @JSONField(name = "ThirdIndId")
    private Set<String> thirdIndId = new HashSet<String>();
    // 店铺
    @JSONField(name = "ShopId")
    private Set<String> shopId = new HashSet<String>();
    // 终端
    @JSONField(name = "TerminalId")
    private Set<String> terminalId = new HashSet<String>();
    // 店铺类型
    @JSONField(name = "ShopType")
    private Set<String> shopType = new HashSet<String>();

    public String getSTime() {
        return sTime;
    }

    public void setSTime(String sTime) {
        this.sTime = sTime;
    }

    public String getETime() {
        return eTime;
    }

    public void setETime(String eTime) {
        this.eTime = eTime;
    }

    public Set<String> getBrandId() {
        return brandId;
    }

    public void setBrandId(Set<String> brandId) {
        this.brandId = brandId;
    }

    public LinkedHashMap<String, String> getSon2MainBandId() {
        return son2MainBandId;
    }

    public void setSon2MainBandId(LinkedHashMap<String, String> son2MainBandId) {
        this.son2MainBandId = son2MainBandId;
    }

    public Set<String> getThirdIndId() {
        return thirdIndId;
    }

    public void setThirdIndId(Set<String> thirdIndId) {
        this.thirdIndId = thirdIndId;
    }

    public Set<String> getShopId() {
        return shopId;
    }

    public void setShopId(Set<String> shopId) {
        this.shopId = shopId;
    }

    public Set<String> getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(Set<String> terminalId) {
        this.terminalId = terminalId;
    }

    public Set<String> getShopType() {
        return shopType;
    }

    public void setShopType(Set<String> shopType) {
        this.shopType = shopType;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("TradeParamVo{");
        sb.append("sTime='").append(sTime).append('\'');
        sb.append(", eTime='").append(eTime).append('\'');
        sb.append(", brandId=").append(brandId);
        sb.append(", son2MainBandId=").append(son2MainBandId);
        sb.append(", thirdIndId=").append(thirdIndId);
        sb.append(", shopId=").append(shopId);
        sb.append(", terminalId=").append(terminalId);
        sb.append(", shopType=").append(shopType);
        sb.append('}');
        return sb.toString();
    }
}
